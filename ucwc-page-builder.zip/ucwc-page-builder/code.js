// Built by scripts/build-figma-plugin.mjs from src/catalog.json, scripts/figma-check-page.js,
// src/builder.js and src/main.js. Do not edit: change those files and run `npm run build:figma-plugin`.
// Rules: version 6 (2026-11-10), fingerprint 911be63443a1

// The blocks the panel offers, in Pick a block's groups, with their library keys.
const CATALOG = {
  "source": "The UCWS Wireframing Toolkit's published components (keys) and its Pick a block page (groups), read 2026-11-10. Each block's purpose, search words and Fits are its component description's. Recipes: the library's Three common pages, its example program page and two of its Example pages, read 2026-11-12.",
  "starter": {
    "name": "Page/Starter page",
    "key": "fbdf5c2c9cafb106d881d2ae3eda4c7b1ddf2d18"
  },
  "header": {
    "name": "Block/Header",
    "key": "849ef9ae4fd7bb2b6c335250a36a71bb699cfa72"
  },
  "footer": {
    "name": "Block/Footer",
    "key": "c0bca1a5d972204cf2d4bf6c2cc4c923f698ce6c"
  },
  "hero": {
    "name": "Block/Hero CTA",
    "key": "8f2b5fa3cc368cb76ae5ce890d4ab7a510cf436a",
    "purpose": "opening the page with its title, over a photo or on colour"
  },
  "columns": {
    "name": "Layout/Columns",
    "key": "e9a6ebb4a30472f685565dbd0bc42a07dae186f3"
  },
  "groups": [
    {
      "name": "Text and detail",
      "blocks": [
        {
          "name": "Block/Text",
          "key": "e0295427edcb5ea1f95fe5b12f9f8a38484af159",
          "purpose": "paragraphs, lists, links, a quote, buttons",
          "words": "text, paragraph, rich text, copy, body",
          "fits": [
            100,
            75,
            66,
            50,
            33,
            25
          ]
        },
        {
          "name": "Block/Info shim",
          "key": "e1101e72bb4b213836b134d07946364ec62d3ea3",
          "purpose": "one line that points to a fact, a tip or a deadline",
          "words": "notice, callout, tip, deadline, alert",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Checklist",
          "key": "74bbf549063b027399ae1aa8ec6b744eea9f53f8",
          "purpose": "three to eight steps in order",
          "words": "steps, process, how to, checklist, numbered",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Accordion",
          "key": "87f24ea0b11b0908cb2fc1c842b2e8e5050d8c8a",
          "purpose": "questions and answers, or detail to tuck away",
          "words": "FAQ, questions, accordion, expand, collapse",
          "fits": [
            100,
            75,
            66,
            50
          ]
        },
        {
          "name": "Block/Accordion (Minimal)",
          "key": "32cb951f86541558982185e02d2406dc626c443c",
          "purpose": "a lighter list of questions beside a heading",
          "words": "FAQ, questions, minimal accordion, expand",
          "fits": [
            100,
            50,
            33
          ]
        },
        {
          "name": "Block/Text grid",
          "key": "4fc365cb9aa5df6e59bd2e0b6ef0d4417f844242",
          "purpose": "topics under rules, two a row, with an optional audience list",
          "words": "text grid, sections, columns, topics",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Table",
          "key": "cea6858ea0a6ead3d9c551ed8a69825a585e410f",
          "component": true,
          "purpose": "data in rows and columns",
          "words": "table, data, rows",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Testimonial",
          "key": "47d2fc17016d135cb2a662fa16db238ccf21c1bc",
          "purpose": "a person's words, with or without a photo",
          "words": "quote, testimonial, review",
          "fits": [
            100
          ]
        }
      ]
    },
    {
      "name": "Ask for an action",
      "blocks": [
        {
          "name": "Block/Banner",
          "key": "6b38cb9b4cfed9bcbe93b23b10796d46baa017fb",
          "purpose": "one message with a button, on a colour or a photo",
          "words": "banner, call to action, CTA, promo",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Sidekick CTA",
          "key": "0cf042cc9f2c459d07d193a85d6f22a569c61196",
          "purpose": "a large photo with a box of text and buttons",
          "words": "sidekick, call to action, CTA, feature",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Image with text",
          "key": "512dbd1127a981d0690183066e30af62be190274",
          "purpose": "a photo beside a coloured panel with a heading and a button",
          "words": "image and text, feature, split, call to action, CTA",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Trio CTA",
          "key": "bdbff72ee7a95b36153083ac69e18179b509b876",
          "purpose": "three next steps with photos",
          "words": "trio, three, photo cards, call to action, CTA",
          "fits": [
            100
          ]
        }
      ]
    },
    {
      "name": "Facts and links to other pages",
      "blocks": [
        {
          "name": "Block/More information",
          "key": "c94ee472c9c86c7e60ce7023aafe8f0c35221ec5",
          "purpose": "one to four facts or services, each with an icon",
          "words": "icons, facts, features, numbers, more info",
          "fits": [
            100,
            75,
            66,
            50,
            33,
            25
          ]
        },
        {
          "name": "Block/Cards",
          "key": "94dba0b90d7f4aac98747d06502db2a76e2e06f1",
          "purpose": "text cards that link to other pages, three a row",
          "words": "cards, links, tiles",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Related content",
          "key": "1f91693a48486b11f2cfb244e32fc4d7cb3c2a86",
          "purpose": "two or three photo cards to related pages",
          "words": "related, links, photo cards",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Thumbnail",
          "key": "96abc416710c51177c821dfdc13f582bae90b95d",
          "purpose": "sections with a small photo each",
          "words": "thumbnail, list with photos, profiles, people",
          "fits": [
            100,
            75,
            66,
            50
          ]
        }
      ]
    },
    {
      "name": "Photos, video and audio",
      "blocks": [
        {
          "name": "Block/Image",
          "key": "e2f84a202edc44631afabd20a52a63c89409fae4",
          "purpose": "one photo with a caption and a credit",
          "words": "image, photo, picture",
          "fits": [
            100,
            75,
            66,
            50,
            33,
            25
          ]
        },
        {
          "name": "Block/Image gallery",
          "key": "cfb81d1867cfc5c5cb214964722f6f1982a2b0d2",
          "purpose": "up to twelve photos that open larger",
          "words": "gallery, photos, lightbox",
          "fits": [
            100,
            75,
            66,
            50
          ]
        },
        {
          "name": "Block/Masonry gallery",
          "key": "67d46c1b9f446c11b510a2d20d73936c4a87f5c9",
          "purpose": "a mosaic of photos in groups of five",
          "words": "masonry, mosaic, photos, gallery",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Streaming media",
          "key": "49b3a0b468a6310296a57538e0b2d6e8176794f3",
          "purpose": "a video or a podcast from YouTube, Spotify and others",
          "words": "video, audio, podcast, YouTube, embed, media",
          "fits": [
            100,
            75,
            66,
            50,
            33
          ]
        }
      ]
    },
    {
      "name": "Feeds and long lists",
      "blocks": [
        {
          "name": "Block/News",
          "key": "a5d9b57252225e7a811e149222a1b9626d8507cf",
          "purpose": "the latest stories from the news feed",
          "words": "news, stories, articles, feed",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Events",
          "key": "916c4d76a48787558089bb9833a0d8f0c5f65056",
          "purpose": "upcoming events from the calendar feed",
          "words": "events, calendar, dates",
          "fits": [
            100,
            50
          ]
        },
        {
          "name": "Block/Page filter",
          "key": "b2c77952edd4c4ca3ee0112ffe51c539da540c5c",
          "purpose": "a long list that people narrow by keyword and tag",
          "words": "filter, search, list, directory, finder",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Profile list",
          "key": "ee33debb5b95e6432fe7cae634e238136654f476",
          "purpose": "people from the Profiles system, as a directory",
          "words": "profiles, people, faculty, staff, directory, team, experts",
          "fits": [
            100
          ]
        }
      ]
    },
    {
      "name": "Structure",
      "blocks": [
        {
          "name": "Layout/Columns",
          "key": "e9a6ebb4a30472f685565dbd0bc42a07dae186f3",
          "layout": true,
          "purpose": "blocks side by side: nine column layouts",
          "words": "columns, layout, two columns, side by side, grid",
          "fits": [
            100
          ]
        },
        {
          "name": "Block/Divider",
          "key": "056eaa1d32727002d84e932f88ab51b67db5b0cd",
          "component": true,
          "purpose": "a rule between two sections",
          "words": "divider, line, rule, separator",
          "fits": [
            100
          ]
        }
      ]
    }
  ],
  "recipes": [
    {
      "name": "Homepage or landing page",
      "purpose": "the front door of a site or a big section: a full photo, what the unit offers, then calls to act and the latest news and events",
      "from": "the library's Block reference, Three common pages",
      "hero": {
        "designs": {
          "Design": "Overlay"
        }
      },
      "blocks": [
        {
          "name": "Block/More information",
          "designs": {
            "Columns": "Three",
            "Accent": "Band"
          }
        },
        {
          "name": "Block/Trio CTA",
          "designs": {
            "Design": "Card"
          }
        },
        {
          "name": "Block/Banner",
          "designs": {
            "Design": "Image"
          }
        },
        {
          "name": "Block/News",
          "designs": {
            "Design": "Images"
          }
        },
        {
          "name": "Block/Events",
          "designs": {
            "Layout": "Full width"
          }
        }
      ]
    },
    {
      "name": "Program or section page",
      "purpose": "a program, service or section of a site: what it is, the details side by side, questions, and where to go next",
      "from": "the library's example on its Build a page page",
      "hero": {
        "designs": {
          "Design": "Mini"
        }
      },
      "blocks": [
        {
          "name": "Block/Text",
          "designs": {
            "Style": "Default"
          }
        },
        {
          "name": "Layout/Columns",
          "designs": {
            "Columns": "50-50"
          },
          "columns": [
            "Block/Text",
            "Block/Image"
          ]
        },
        {
          "name": "Block/More information",
          "designs": {
            "Columns": "Three",
            "Accent": "Band"
          }
        },
        {
          "name": "Block/Accordion",
          "designs": {
            "Design": "FAQ"
          },
          "counts": {
            "Sections (2 to 8)": 3
          }
        },
        {
          "name": "Block/Banner",
          "designs": {
            "Design": "Colour"
          }
        },
        {
          "name": "Block/Related content",
          "designs": {
            "Items": "Three"
          }
        }
      ]
    },
    {
      "name": "How-to page",
      "purpose": "steps to follow: who it is for, the deadline, the steps, then questions and help",
      "from": "the library's Example: Arts Co-op How to Apply",
      "hero": {
        "designs": {
          "Design": "Text gradient"
        }
      },
      "blocks": [
        {
          "name": "Block/Text grid",
          "designs": {
            "Accent": "Dark orange"
          }
        },
        {
          "name": "Block/Info shim",
          "designs": {
            "Style": "Callout",
            "Accent": "Dark orange"
          }
        },
        {
          "name": "Block/Checklist",
          "designs": {
            "Colour": "Light orange",
            "Accent": "Band"
          }
        },
        {
          "name": "Block/Divider"
        },
        {
          "name": "Block/Accordion",
          "designs": {
            "Design": "FAQ"
          },
          "counts": {
            "Sections (2 to 8)": 5
          }
        },
        {
          "name": "Block/Banner",
          "designs": {
            "Design": "Wide double"
          },
          "switches": {
            "Space below": false
          }
        }
      ]
    },
    {
      "name": "Department homepage",
      "purpose": "a department or unit's own homepage: a banner, who they are beside a photo, a podcast or video, ways in and upcoming events",
      "from": "the library's Example: Department of Pediatrics",
      "hero": {
        "designs": {
          "Design": "Mini"
        },
        "switches": {
          "Show intro": false,
          "Show buttons": false,
          "Space below": false
        }
      },
      "blocks": [
        {
          "name": "Block/Banner",
          "designs": {
            "Design": "Image"
          },
          "switches": {
            "Page without a full-bleed hero": true
          }
        },
        {
          "name": "Block/Divider"
        },
        {
          "name": "Layout/Columns",
          "designs": {
            "Columns": "50-50"
          },
          "columns": [
            "Block/Text",
            "Block/Image"
          ]
        },
        {
          "name": "Block/Streaming media",
          "designs": {
            "Design": "Audio"
          }
        },
        {
          "name": "Block/Divider"
        },
        {
          "name": "Block/Trio CTA",
          "designs": {
            "Design": "Card"
          },
          "switches": {
            "Show heading": false
          }
        },
        {
          "name": "Block/Events",
          "designs": {
            "Layout": "Full width"
          }
        }
      ]
    },
    {
      "name": "People page",
      "purpose": "a list of faculty or staff: a short introduction, then everyone's profile with a search",
      "from": "UCalgary's people pages: 123 Profile list blocks on 85 of them",
      "hero": {
        "designs": {
          "Design": "Text stacked"
        },
        "switches": {
          "Show buttons": false
        }
      },
      "blocks": [
        {
          "name": "Block/Text",
          "designs": {
            "Style": "Default"
          }
        },
        {
          "name": "Block/Profile list",
          "designs": {
            "Search": "On"
          }
        }
      ]
    }
  ]
};

// The page check, run on a page once it is built.
async function runCheck(PAGE_ID, FRAME_ID, OTHER_PAGES) {
  const issues = [];
  // The rules' version: raise it, and set the date, with every change to the rules (the plugin shows it,
  // so a designer can tell whether their copy is current). scripts/build-figma-plugin.mjs refuses to build
  // when the rules changed and the version didn't.
  const RULES = { version: 6, date: '2026-11-10' };
  // One finding: the page frame it is on (its name, and its id as `frame`), where, what to do, the layer
  // to look at (`id`), how much it matters (`level`) and which part of the check found it (`section`).
  //   level:   'must' (must fix: the page can't be built as designed), 'check' (check by hand: the check
  //            can't decide), 'tip' (worth a look)
  //   section: 'structure' (blocks, layout rows, items, limits) or 'content' (the words on the page)
  const LEVELS = ['must', 'check', 'tip'];
  const add = (frame, where, message, node, level = 'must', section = 'structure') => issues.push({ page: frame.name, frame: frame.id, where, message, id: (node || frame).id, level, section });
  const setOf = async (inst) => { const m = await inst.getMainComponentAsync(); if (!m) return null; return m.parent && m.parent.type === 'COMPONENT_SET' ? m.parent : m; };
  const bare = (key) => key.replace(/#[^#]*$/, '');
  const maxOf = (name) => { const m = /\(max ([\d,]+)\)\s*$/.exec(bare(name)); return m ? Number(m[1].replace(/,/g, '')) : null; };
  const countOf = (name) => {
    let m = /\((\d+) to (\d+)\)\s*$/.exec(name); if (m) return { min: Number(m[1]), max: Number(m[2]) };
    m = /\((\d+) or more\)\s*$/.exec(name); if (m) return { min: Number(m[1]), max: Infinity };
    m = /\(max (\d+)\)\s*$/.exec(name); if (m) return { min: 0, max: Number(m[1]) };
    return null;
  };
  const unescape = (s) => String(s || '').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  // Blocks of the Block Library the design system has only at `spec` (blocks.md → Current blocks): no
  // component yet. scripts/check-page-check.mjs fails when this list and blocks.md differ.
  const SPEC_BLOCKS = ['Animation', 'Campus map', 'Important dates', 'Marketo', 'Price list', 'Progress', 'Schedule'];
  const specName = (name) => SPEC_BLOCKS.find((b) => b.toLowerCase() === String(name).replace(/^Block\//, '').trim().toLowerCase());
  const fitsOf = (set) => { const m = /Fits:\s*([^\n.]+)/.exec(unescape(set.description)); return m ? (m[1].match(/\d+/g) || []).map(Number) : [100]; };

  async function checkLimits(frame, node, label) {
    // The instance's own text properties.
    if (node.type === 'INSTANCE') {
      for (const [key, prop] of Object.entries(node.componentProperties)) {
        if (prop.type !== 'TEXT') continue;
        const max = maxOf(key);
        if (max && String(prop.value).length > max) add(frame, label, `${bare(key)}: ${String(prop.value).length} characters, the limit is ${max}.`, node);
      }
      const max = maxOf(node.name);
      if (max) {
        const t = node.findOne((n) => n.type === 'TEXT' && n.visible);
        if (t && t.characters.length > max) add(frame, label, `${node.name}: ${t.characters.length} characters, the limit is ${max}.`, t);
      }
    }
    if (node.type === 'TEXT' && node.visible) {
      const max = maxOf(node.name);
      if (max && node.characters.length > max) add(frame, label, `${node.name}: ${node.characters.length} characters, the limit is ${max}.`, node);
    }
    if ('children' in node) for (const c of node.children) if (c.visible) await checkLimits(frame, c, label);
  }

  // A list can hold its items in a grid frame (Cards: "Card grid"), so that a row's cards share a height
  // and a new row comes by itself. Figma keeps each item in its cell, so deleting one leaves a gap.
  function gridItems(frame, grid, what) {
    const kids = grid.children.filter((k) => k.visible);
    const cols = grid.gridColumnCount;
    const cells = kids.map((k) => k.gridRowAnchorIndex * cols + k.gridColumnAnchorIndex).sort((x, y) => x - y);
    if (cells.some((cell, i) => cell !== i)) add(frame, what, 'A gap between the items: drag each item after the gap one cell back, so the rows fill from the left.', grid);
    else if (grid.gridRowCount > Math.max(1, Math.ceil(kids.length / cols))) add(frame, what, `An empty row is left at the end: select "${grid.name}" and lower its row count.`, grid);
    return kids;
  }

  // A block's item slots: the count its name allows, and only the items its preferred values list.
  // An item can hold slots of its own (an accordion section's sub-sections), so this follows them.
  async function checkItems(frame, inst, label) {
    if (!inst.findAllWithCriteria({ types: ['SLOT'] }).length) return;
    const set = await setOf(inst);
    const defs = set ? set.componentPropertyDefinitions : {};
    const walk = async (node) => {
      for (const c of node.children) {
        if (!c.visible) continue;
        if (c.type === 'SLOT') {
          const key = Object.keys(defs).find((k) => defs[k].type === 'SLOT' && bare(k) === c.name);
          const allowed = key ? (defs[key].preferredValues || []).map((p) => p.key) : [];
          const what = `${label} → ${c.name.replace(/\s*\([^)]*\)\s*$/, '')}`;
          const items = c.children.filter((k) => k.visible).flatMap((k) => (k.type === 'FRAME' && k.layoutMode === 'GRID' ? gridItems(frame, k, what) : [k]));
          const range = countOf(c.name);
          if (range && items.length < range.min) add(frame, what, `${items.length} here: at least ${range.min}.`, c);
          if (range && items.length > range.max) add(frame, what, `${items.length} here: at most ${range.max}.`, c);
          for (const item of items) {
            const itemSet = item.type === 'INSTANCE' ? await setOf(item) : null;
            if (!itemSet || (allowed.length && !allowed.includes(itemSet.key))) add(frame, what, `"${item.name}" is not one of this block's items: it was drawn by hand, detached or taken from another block.`, item);
            else await checkItems(frame, item, what);
          }
        } else if (c.type === 'INSTANCE') await checkItems(frame, c, label);
        else if ('children' in c) await walk(c);
      }
    };
    await walk(inst);
  }

  // A block swapped into a region arrives in its full-width design, whose content is wider than the
  // column: the first visible layer that reaches past the region's sides.
  function widerThan(node, slot) {
    const s = slot.absoluteBoundingBox;
    let found = false;
    const walk = (n) => {
      if (found || !n.visible) return;
      const b = n.absoluteBoundingBox;
      if (b && b.width > 0 && (b.x < s.x - 1 || b.x + b.width > s.x + s.width + 1)) { found = true; return; }
      if ('children' in n) n.children.forEach(walk);
    };
    walk(node);
    return found;
  }

  const propOf = (inst, name) => { const k = Object.keys(inst.componentProperties || {}).find((key) => bare(key) === name); return k ? inst.componentProperties[k].value : undefined; };

  // What only a person can check, where the block shows it (blocks.md; content.md → Images and media).
  function reminders(frame, node, name, label) {
    const design = String(propOf(node, 'Design') || '');
    const R = (message) => add(frame, label, message, node, 'check');
    const photoText = 'White text over a photo: check its contrast by hand against the lightest part of the photo under the text (4.5:1, and 3:1 for a heading), even with the scrim.';
    if (name === 'Block/Hero CTA' && /^Overlay/.test(design)) R(photoText);
    if (name === 'Block/Banner' && /^Image/.test(design)) {
      if (design === 'Image only') R('The words are in the picture: give the image alt text that says what the picture says.');
      else R(photoText);
    }
    if (name === 'Block/Sidekick CTA') R('The box sits over the photo: check it doesn\'t cover the photo\'s focal point.');
    if (name === 'Block/Streaming media') {
      if (/^Video/.test(design)) R('A video needs captions: check them, and edit automatic captions for accuracy.');
      else if (/^Audio/.test(design)) R('A podcast or audio needs a transcript, on the page below the player or linked.');
    }
  }

  // The page's build list (Phase 6): each block in order, with its designs and switches (variant and
  // boolean properties), its item lists (how many in each) and its text, layer by layer; a layout row with
  // its regions and their blocks. The Header and Footer carry the site's own, so only their switches and
  // the Header's navigation.
  async function buildItem(node) {
    const set = await setOf(node);
    const name = set ? set.name : node.name;
    // Designs (variants) first, then switches (booleans) by name, so "Show step 3" comes before "Show step 4".
    const entries = Object.entries(node.componentProperties || {}).filter(([, p]) => p.type === 'VARIANT' || p.type === 'BOOLEAN');
    const byName = (a, b) => bare(a[0]).localeCompare(bare(b[0]), 'en', { numeric: true });
    const props = {};
    for (const [key, p] of [...entries.filter(([, p]) => p.type === 'VARIANT'), ...entries.filter(([, p]) => p.type === 'BOOLEAN').sort(byName)]) props[bare(key)] = p.value;
    const item = { block: name.replace(/^Block\//, ''), id: node.id, properties: props };
    if (/^Layout\//.test(name)) {
      item.regions = [];
      for (const s of node.findAllWithCriteria({ types: ['SLOT'] }).filter((x) => /\(\d+%\)\s*$/.test(x.name))) {
        const blocks = [];
        for (const k of s.children) if (k.visible && k.type === 'INSTANCE') blocks.push(await buildItem(k));
        item.regions.push({ region: s.name, blocks });
      }
      return item;
    }
    if (name === 'Block/Header') {
      item.navigation = (await navOf(node)).map((n) => n.label);
      return item;
    }
    if (name === 'Block/Footer') return item;
    const lists = node.findAllWithCriteria({ types: ['SLOT'] }).filter((s) => shown(s, node));
    if (lists.length) item.lists = lists.map((s) => ({ list: s.name.replace(/\s*\([^)]*\)\s*$/, ''), items: s.children.filter((k) => k.visible).flatMap((k) => (k.type === 'FRAME' && k.layoutMode === 'GRID' ? k.children.filter((c) => c.visible) : [k])).length }));
    // Its text, leaving out what Drupal draws by itself: bullets and ticks, and the numbers of steps and
    // sub-sections.
    item.text = [];
    for (const t of node.findAllWithCriteria({ types: ['TEXT'] })) {
      if (!shown(t, node) || !t.characters.trim() || /^[\s•·✓✔→*–—-]+$/.test(t.characters)) continue;
      if (/^(Checklist\/Step number|Accordion\/Sub-section number)/.test(await styleOf(t))) continue;
      item.text.push({ layer: t.name.replace(/\s*\(max [\d,]+\)\s*$/, ''), text: t.characters });
    }
    return item;
  }

  // The Header's navigation: its top-level items' labels, in order.
  async function navOf(header) {
    const nav = [];
    for (const i of header.findAllWithCriteria({ types: ['INSTANCE'] })) {
      if (!shown(i, header)) continue;
      const set = await setOf(i);
      if (set && /nav item$/.test(set.name)) nav.push({ label: String(propOf(i, 'Label') || ''), node: i });
    }
    return nav;
  }

  // The page's blocks (not layout rows) in page order, regions left to right: the content checks read them.
  let placed = [];

  async function checkBlock(frame, node, regionWidth, slot) {
    const set = node.type === 'INSTANCE' ? await setOf(node) : null;
    const name = set ? set.name : null;
    if (!name || !(name.startsWith('Block/') || name.startsWith('Layout/'))) {
      if (name && /^_?Layout part\/Empty region/.test(name)) add(frame, slot ? slot.name : node.name, 'An empty-region placeholder is still here: delete it, or swap it for a block.', node);
      else if (name === 'Annotation') add(frame, node.name, 'An annotation inside the page: move it beside the page frame, where it is not part of the page.', node);
      else if (specName(node.name)) add(frame, node.name, `${specName(node.name)} is a Block Library block this file doesn't have yet (blocks.md: spec), so it is drawn by hand: check it against its Block Library page before it is built.`, node, 'tip');
      else add(frame, node.name, 'Not a block: it was drawn by hand or detached, so it cannot be built in Drupal.', node);
      return null;
    }
    if (name === 'Layout/Columns') {
      if (regionWidth) { add(frame, node.name, 'A layout row inside a region: Drupal has no nested layouts.', node); return name; }
      for (const s of node.findAllWithCriteria({ types: ['SLOT'] })) {
        if (!/\(\d+%\)\s*$/.test(s.name)) continue; // a block's own item slot, checked with its block
        const w = Number((/\((\d+)%\)/.exec(s.name) || [])[1]);
        if (!s.children.length) add(frame, s.name, 'This region is empty.', s);
        for (const child of s.children) await checkBlock(frame, child, w, s);
      }
      return name;
    }
    const short = name.replace('Block/', '');
    const label = regionWidth ? `${slot.name} → ${short}` : short;
    if (specName(short)) add(frame, label, `${short} is at spec in the design system (blocks.md): it has no code yet, so check it against its Block Library page.`, node, 'tip');
    reminders(frame, node, name, label);
    if (regionWidth) {
      const fits = fitsOf(set);
      if (!fits.includes(regionWidth)) add(frame, label, `${short} doesn't fit a ${regionWidth}% column (it fits ${fits.map((f) => f + '%').join(', ')}).`, node);
      else if (Math.abs(node.width - slot.width) > 1) add(frame, label, `${short} is ${Math.round(node.width)} wide in a ${Math.round(slot.width)} region: choose its In a region design and set its width to Fill.`, node);
      else if (widerThan(node, slot)) add(frame, label, `${short}'s content is wider than its column: choose its In a region design.`, node);
    } else if (Math.abs(node.width - 1440) > 1) add(frame, short, `${short} is ${Math.round(node.width)} wide: a block on the page is 1440 wide.`, node);
    await checkItems(frame, node, label);
    await checkLimits(frame, node, label);
    placed.push({ node, name, label });
    return name;
  }

  // A page's blocks in order: its own layers, with the template's slot (Blocks) opened in place.
  function pageBlocks(frame) {
    return frame.children.flatMap((c) => (c.type === 'SLOT' ? c.children.filter((k) => k.visible) : [c]));
  }

  async function isPage(f) {
    if (Math.abs(f.width - 1440) > 1) return false;
    if (f.type === 'INSTANCE') return /^Page\//.test(((await setOf(f)) || {}).name || '');
    if (f.type !== 'FRAME') return false;
    for (const c of f.children) if (c.type === 'INSTANCE' && ((await setOf(c)) || {}).name === 'Block/Header') return true;
    return false;
  }

  async function checkFrame(frame) {
    const names = [];
    placed = [];
    const blocks = pageBlocks(frame);
    for (const child of blocks) names.push(await checkBlock(frame, child, 0, null));
    if (names[0] !== 'Block/Header') add(frame, 'Page', 'The Header comes first.', blocks[0]);
    if (names[names.length - 1] !== 'Block/Footer') add(frame, 'Page', 'The Footer comes last.', blocks[blocks.length - 1]);
    const heroes = names.filter((n) => n === 'Block/Hero CTA').length;
    if (heroes !== 1) add(frame, 'Page', `A page has one Hero CTA; this one has ${heroes}.`);
    else if (names[1] !== 'Block/Hero CTA') add(frame, 'Page', 'The Hero CTA comes right after the Header.', blocks[1]);
    for (const limited of ['Block/Trio CTA', 'Block/Image with text']) {
      let run = 0;
      names.forEach((n, i) => { run = n === limited ? run + 1 : 0; if (run === 3) add(frame, 'Page', `More than two ${limited.replace('Block/', '')} blocks in a row.`, blocks[i]); });
    }
    // Image banners are taller on a page without a full-bleed hero (blocks.md → Banner, Page mode): every
    // hero is full-bleed but the mini image hero.
    const prop = propOf;
    const hero = blocks.find((c, i) => names[i] === 'Block/Hero CTA');
    const fullBleedHero = hero ? !/^Mini/.test(String(prop(hero, 'Design'))) : false;
    blocks.forEach((child, i) => {
      if (names[i] !== 'Block/Banner') return;
      const design = String(prop(child, 'Design'));
      const taller = prop(child, 'Page without a full-bleed hero');
      if (!/^Image/.test(design) || design === 'Image only' || taller === undefined) return;
      if (fullBleedHero && taller) add(frame, 'Banner', 'This page starts with a full-bleed hero, so its image banners are the shorter ones: switch off "Page without a full-bleed hero".', child);
      if (!fullBleedHero && !taller) add(frame, 'Banner', 'This page has a mini hero or none, so its image banners are taller: switch on "Page without a full-bleed hero".', child);
    });
    if (frame.layoutMode !== 'VERTICAL' || frame.itemSpacing !== 0) add(frame, 'Page', 'The page frame should be a vertical auto layout with no gap, so blocks stack as on the site.');
    // A page dragged in from the library keeps the template's name ("Page/Starter page"), so two pages of a
    // file read the same in the report, the build list and the comparison across pages.
    if (/^Page\//.test(frame.name)) add(frame, 'Page', `This page is still named "${frame.name}", after the library's template: rename it after the page (its title), so the report, the build list and the checks across pages say which page is which.`, frame, 'tip');
    const h1 = await checkContent(frame, placed, heroes === 1);
    const header = blocks.find((c, i) => names[i] === 'Block/Header');
    sites.push({ frame, unit: unitOf(header), header, nav: header ? await navOf(header) : [], h1, checked: true });
    const build = [];
    for (const c of blocks) if (c.type === 'INSTANCE') build.push(await buildItem(c));
    return { blocks: names.length, build };
  }

  // A page's site: the Header's unit name ("Unit" text).
  const unitOf = (header) => (header ? header.findAllWithCriteria({ types: ['TEXT'] }).filter((t) => t.name === 'Unit' && shown(t, header)).map((t) => t.characters.trim()).join(' / ') : '');

  // What the comparison needs of a page that isn't checked (on another Figma page): its site, navigation
  // and H1 (its one Heading/H1 text outside the Header and Footer).
  async function siteOf(frame) {
    let header = null;
    const h1 = [];
    for (const c of pageBlocks(frame)) {
      if (c.type !== 'INSTANCE') continue;
      const name = ((await setOf(c)) || {}).name;
      if (name === 'Block/Header') { if (!header) header = c; continue; }
      if (CHROME.has(name)) continue;
      for (const t of c.findAllWithCriteria({ types: ['TEXT'] })) if (shown(t, c) && /^Heading\/H1\b/.test(await styleOf(t))) h1.push({ text: t.characters, node: t });
    }
    return { frame, unit: unitOf(header), header, nav: header ? await navOf(header) : [], h1: h1.length === 1 ? h1[0] : null };
  }

  // Across pages (Phase 4): pages of one site, by the Header's unit name, have the same navigation (a site
  // has one main menu) and different H1s (page titles are unique: content.md → Headings and page titles).
  // The pages are the ones checked together and, with OTHER_PAGES, the file's other pages (in file order:
  // Figma pages, then frames). A site's first page is its reference: a checked page whose navigation differs
  // from it is must fix. A checked page with the H1 of another page of its site is checked by hand: of two
  // checked pages only the later one, so it is reported once. Findings only go on checked pages.
  const sites = [];
  function acrossPages(elsewhere) {
    const all = sites.concat(elsewhere);
    if (elsewhere.length) {
      const pages = figma.root.children;
      const pos = (p) => { const pg = p.page || p.frame.parent; return pages.indexOf(pg) * 1e6 + pg.children.indexOf(p.frame); };
      all.sort((a, b) => pos(a) - pos(b));
    }
    const named = (p) => (p.where ? `"${labelOf(p.frame)}" (on the Figma page "${p.where}")` : `"${labelOf(p.frame)}"`);
    const bySite = {};
    for (const p of all) if (p.unit) (bySite[p.unit] = bySite[p.unit] || []).push(p);
    for (const [unit, list] of Object.entries(bySite)) {
      const first = list[0];
      const a = first.nav.map((n) => n.label).join(' | ');
      list.forEach((p, i) => {
        if (!p.checked) return;
        const b = p.nav.map((n) => n.label).join(' | ');
        if (i > 0 && a !== b) add(p.frame, 'Header', `The navigation differs from ${named(first)}, a page of the same site (${unit}): a site has one main menu. There: ${a || 'none'}. Here: ${b || 'none'}.`, p.header);
        if (!p.h1) return;
        const key = p.h1.text.trim().toLowerCase();
        const twin = list.find((q, j) => q !== p && q.h1 && q.h1.text.trim().toLowerCase() === key && (!q.checked || j < i));
        if (twin) add(p.frame, 'Page', `The same H1 as ${named(twin)} ("${clip(p.h1.text)}"): each page of a site needs its own title. Check which one is right.`, p.h1.node, 'check', 'content');
      });
    }
  }

  // ---- Content: the words on the page (docs/content.md; figma.md → Page check plan, Phase 2) -----------
  // Read from the text already in the file: text layers, the text properties of buttons, links and
  // navigation items, and link addresses set on text. The Header and Footer carry the site's standard
  // navigation and footer, so only their navigation labels are checked.

  const styleNames = {};
  async function styleOf(t) {
    const id = t.textStyleId;
    if (typeof id !== 'string' || !id) return '';
    if (!(id in styleNames)) { const st = await figma.getStyleByIdAsync(id); styleNames[id] = st ? st.name : ''; }
    return styleNames[id];
  }
  const shown = (n, root) => { for (let p = n; p && p !== root; p = p.parent) if (p.visible === false) return false; return true; };
  const wordsOf = (s) => String(s).match(/[A-Za-z0-9][A-Za-z0-9’'&.-]*/g) || [];
  const clip = (s, n = 40) => { const t = String(s).replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1) + '…' : t; };
  const sentencesOf = (s) => String(s).replace(/([.!?])\s+(?=[A-Z0-9"“‘'(])/g, '$1\u0000').split('\u0000').map((x) => x.trim()).filter((x) => wordsOf(x).length);
  const SMALL = new Set('a an and as at but by for from in into nor of on or per the to vs via with'.split(' '));
  const isAcronym = (w) => /^[A-Z][A-Z0-9]+s?$/.test(w);
  // Title Case: every word after the first, other than short joining words and acronyms, starts with a capital.
  function titleCase(text) {
    const rest = wordsOf(text).slice(1).filter((w) => /^[A-Za-z]/.test(w) && !SMALL.has(w.toLowerCase()) && !isAcronym(w));
    return rest.length > 0 && rest.every((w) => /^[A-Z]/.test(w));
  }
  const placeholder = (s) => /\bstand-in\b|lorem ipsum/i.test(s);

  // Link and button text that doesn't say where it goes (content.md → Buttons and links).
  const VAGUE = new Set(['click here', 'click', 'here', 'learn more', 'read more', 'more', 'more info', 'more information', 'find out more', 'see more', 'details', 'link', 'this link', 'go']);
  const vague = (s) => VAGUE.has(String(s).toLowerCase().replace(/[^a-z ]/g, ' ').replace(/\s+/g, ' ').trim());
  const UNAPPROVED_FORM = /forms\.gle|docs\.google\.com\/forms|jotform\.|typeform\./i;
  const VERBS = new Set(('access apply ask attend begin book browse build buy call change chat check choose compare complete connect contact continue create discover donate download email enrol enter explore filter find follow get give go hear join learn listen log login make meet open order pay plan prepare print reach read register renew report request reserve reset return review save schedule search see select send share shop show sign start submit subscribe support take tell try update upload use view visit vote watch write').split(' '));

  // content.md → Grammar and style: [pattern, what to write instead (or a function of the match that
  // writes it)]. Body text only.
  const SHORT_MONTH = { January: 'Jan.', February: 'Feb.', August: 'Aug.', September: 'Sept.', October: 'Oct.', November: 'Nov.', December: 'Dec.' };
  const FULL_MONTH = { Mar: 'March', Apr: 'April', Jun: 'June', Jul: 'July' };
  const STYLE = [
    [/\banalys(e|es|ed|ing)\b/i, 'analyze'], [/\bprogrammes?\b/i, 'program'], [/\be-mail\b/i, 'email'],
    [/\benroll(s|ment|ments)?\b/i, 'enrol, enrolment'], [/\badvisors?\b/i, 'adviser'], [/\barcheolog/i, 'archaeology'],
    [/\bcent(er|ered|ers)\b/i, 'centre'], [/\bcentred around\b/i, 'centred on'], [/\bon-line\b/i, 'online'],
    [/\bstart-ups?\b/i, 'startup'], [/\bfund[- ]rais/i, 'fundraising'], [/\btheaters?\b/i, 'theatre'],
    [/\d\s?%/, 'per cent (% only in headlines)'],
    [/\b\d{1,2}:00\s?(?:[ap]\.m\.|[ap]m\b)/i, '8 a.m., without ":00"'],
    [/\b\d{1,2}(:\d\d)?\s?([AaPp][Mm]|[AP]\.M\.)(?![A-Za-z])/, 'a.m. or p.m.'],
    [/\b(1[3-9]|2[0-3]):[0-5]\d\b/, 'the 12-hour clock (5:30 p.m.)'],
    [/\b(January|February|August|September|October|November|December) (\d{1,2})\b/, (m) => `${SHORT_MONTH[m[1]]} ${m[2]}`],
    [/\b(Mar|Apr|Jun|Jul)\. ?(\d{1,2})\b/, (m) => `${FULL_MONTH[m[1]]} ${m[2]}`], [/\bSep\. ?\d/, 'Sept.'],
  ];
  // content.md → Inclusive language. Check by hand: context decides.
  const INCLUSIVE = [
    [/\bpolicem[ae]n\b/i, 'police officer'], [/\bfirem[ae]n\b/i, 'firefighter'], [/\bmailm[ae]n\b/i, 'mail carrier'],
    [/\balderm[ae]n\b/i, 'councillor'], [/\bstewardess(es)?\b/i, 'flight attendant'],
    [/\bCanada[’']s Indigenous Peoples?\b/i, 'Indigenous Peoples in Canada'], [/\bnatives?\b/i, 'Indigenous, or the community’s own name'],
    [/\bsexual preference\b/i, 'sexual orientation'], [/\btransgendered\b/i, 'transgender'], [/\bhomosexuals?\b/i, 'gay, lesbian'],
    [/\bpioneer(s|ing|ed)?\b/i, 'a word without colonial overtones'], [/\bwalk(s|ed|ing)? the stage\b/i, 'cross the stage'], [/\bgung[- ]ho\b/i, 'enthusiastic'],
  ];
  const CLAIMS = /\b(proves?|proven|cures?|breakthroughs?|first[- ]ever|unprecedented|transformational|groundbreaking|ground-breaking|world-leading|game-changing|revolutionary)\b/i;
  const PERSONAL_EMAIL = /\b[a-z]+[._-][a-z]+@ucalgary\.ca\b/i;
  // Acronyms anyone reading knows, and degrees (content.md → Grammar and style).
  const KNOWN = new Set(('AI GPS NASA USA US UK OK FAQ FAQs PDF URL TV CEO ID GPA UCalgary CV PhD BA BSc BComm BEd BFA BKin BMus BN BSW MA MSc MBA MD MEd MEng MFA MN MSW JD LLM DVM EdD DBA DN DDes MArch MKin LLD SAIT CPR COVID STEM').split(' '));
  const NOT_BODY = /^(Heading\/|Button\/|Header\/|Footer\/|Label\/|Checklist\/Step number|Accordion\/Sub-section number|Events\/Date day)/;
  const CHROME = new Set(['Block/Header', 'Block/Footer']);

  // Grade level (Flesch–Kincaid) of a stretch of text.
  function syllables(word) {
    const w = word.toLowerCase().replace(/[^a-z]/g, '');
    if (!w) return 0;
    if (w.length <= 3) return 1;
    const groups = w.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '').replace(/^y/, '').match(/[aeiouy]{1,2}/g);
    return Math.max(1, groups ? groups.length : 1);
  }
  function grade(text) {
    const ws = wordsOf(text).filter((w) => /[A-Za-z]/.test(w));
    const ss = Math.max(1, sentencesOf(text).length);
    if (!ws.length) return 0;
    const syl = ws.reduce((n, w) => n + syllables(w), 0);
    return 0.39 * (ws.length / ss) + 11.8 * (syl / ws.length) - 15.59;
  }

  async function checkContent(frame, blocks, oneHero) {
    const C = (where, message, node, level) => add(frame, where, message, node, level, 'content');
    const headings = [];
    const prose = [];   // { text, node, label } body text, page order
    const actions = []; // { kind: 'button'|'link', text, url, node, label }

    for (const { node: block, name, label } of blocks) {
      const chrome = CHROME.has(name);
      const texts = block.findAllWithCriteria({ types: ['TEXT'] }).filter((t) => shown(t, block));
      const instances = [block].concat(block.findAllWithCriteria({ types: ['INSTANCE'] }).filter((i) => shown(i, block)));

      // Stand-in copy (must fix) and the library's sample text (check by hand), once per block.
      const stand = texts.filter((t) => placeholder(t.characters));
      if (stand.length) C(label, `${stand.length === 1 ? 'A text is' : stand.length + ' texts are'} still stand-in copy ("${clip(stand[0].characters)}"): write the page's own.`, stand[0], 'must');
      const samples = [];
      for (const inst of instances) {
        const set = await setOf(inst);
        if (!set) continue;
        const sname = set.name;
        const defs = set.componentPropertyDefinitions || {};
        for (const [key, prop] of Object.entries(inst.componentProperties || {})) {
          if (prop.type !== 'TEXT') continue;
          const text = String(prop.value);
          const field = bare(key).replace(/\s*\([^)]*\)\s*$/, '');
          if (!chrome && field !== 'Number' && defs[key] && defs[key].defaultValue === prop.value && !placeholder(text)) samples.push({ text, inst });
          if (sname === '_Button' && field === 'Label') actions.push({ kind: 'button', text, node: inst, label });
          else if ((sname === '_Link' && field === 'Label') || field === 'Link text') actions.push({ kind: 'link', text, node: inst, label });
          else if (/nav item$/.test(sname) && field === 'Label') {
            // content.md → Navigation labels: top level.
            const ws = wordsOf(text).filter((w) => w !== '&');
            const why = [];
            if (ws.length > 2) why.push('two words at most');
            if (/\band\b/i.test(text)) why.push('"&" for "and"');
            if (/\b(our|my|your)\b/i.test(text)) why.push('no "our", "my" or "your"');
            if (/\?|^(how|what|where|why|when|who|can)\b/i.test(text)) why.push('a noun, not a question');
            if (ws.slice(1).some((w) => /^[a-z]/.test(w) && !SMALL.has(w))) why.push('Title Case');
            if (why.length) C(label, `Navigation label "${clip(text)}": ${why.join('; ')}.`, inst, 'tip');
          } else if (/^_?Chip$/.test(sname) && field === 'Label') {
            // content.md → Navigation labels and tags.
            const why = [];
            if (text !== text.toLowerCase() && !wordsOf(text).every(isAcronym)) why.push('lowercase');
            if (wordsOf(text).length > 2) why.push('one or two words');
            if (wordsOf(text).some(isAcronym) && !wordsOf(text).every((w) => KNOWN.has(w))) why.push('the full term, not an acronym');
            if (why.length) C(label, `Tag "${clip(text)}": ${why.join('; ')}.`, inst, 'tip');
          }
        }
      }
      if (samples.length) C(label, `${samples.length === 1 ? 'A text is' : samples.length + ' texts are'} still the library's sample text ("${clip(samples[0].text)}"): replace ${samples.length === 1 ? 'it' : 'them'}, or keep ${samples.length === 1 ? 'it if it is' : 'them if they are'} this page's own.`, samples[0].inst, 'check');

      for (const t of texts) {
        const style = await styleOf(t);
        const h = /^Heading\/H(\d)/.exec(style);
        if (h && !chrome) headings.push({ level: Number(h[1]), text: t.characters, node: t, label });
        // Link addresses set on the text itself.
        if (typeof t.getStyledTextSegments === 'function') {
          for (const seg of t.getStyledTextSegments(['hyperlink'])) {
            if (seg.hyperlink && seg.hyperlink.type === 'URL') actions.push({ kind: 'link', text: seg.characters, url: seg.hyperlink.value, node: t, label });
          }
        }
        if (style === 'Header/Menu link') {
          const ws = wordsOf(t.characters).filter((w) => w !== '&');
          const why = [];
          if (ws.length > 4) why.push('two to four words');
          if (/\b(our|my|your)\b/i.test(t.characters)) why.push('no "our", "my" or "your"');
          if (why.length) C(label, `Navigation label "${clip(t.characters)}": ${why.join('; ')}.`, t, 'tip');
        }
        if (UNAPPROVED_FORM.test(t.characters)) C(label, `A link to a form tool the university doesn't approve ("${clip(t.characters)}"): use a Drupal webform, Qualtrics or SharePoint.`, t, 'must');
        if (!chrome && !h && !NOT_BODY.test(style) && !placeholder(t.characters) && t.characters.trim()) prose.push({ text: t.characters, node: t, label });
      }
    }

    // Headings: one H1 (the hero's), no skipped level, sentence case, no closing period or "!".
    // The styles say how big a heading is, not its level in the page's code, so a skip is checked by hand.
    const h1 = headings.filter((x) => x.level === 1);
    const title = h1.length === 1 ? h1[0] : null;
    if (oneHero && h1.length !== 1) C('Page', `A page has one H1 (the Hero CTA's title); this one has ${h1.length}.`, h1[1] ? h1[1].node : null, 'must');
    let previous = 0;
    for (const x of headings) {
      if (previous && x.level > previous + 1) C(x.label, `"${clip(x.text)}" is an H${x.level} after an H${previous}: check that no heading level is skipped in the page's code.`, x.node, 'check');
      previous = x.level;
      const why = [];
      if (/[.!]\s*$/.test(x.text) && !/\.\.\.\s*$|…\s*$/.test(x.text)) why.push('no closing period or "!"');
      if (titleCase(x.text)) why.push('sentence case, unless these are proper names');
      if (why.length) C(x.label, `Heading "${clip(x.text)}": ${why.join('; ')}.`, x.node, 'tip');
    }

    // Buttons and links.
    const byText = {};
    for (const a of actions) {
      const text = String(a.text).trim();
      if (vague(text)) { C(a.label, `${a.kind === 'button' ? 'Button' : 'Link'} text "${clip(text)}" doesn't say where it goes: name the destination or action ("Read the program requirements").`, a.node, 'must'); continue; }
      if (a.url && UNAPPROVED_FORM.test(a.url)) C(a.label, `"${clip(text)}" links to a form tool the university doesn't approve: use a Drupal webform, Qualtrics or SharePoint.`, a.node, 'must');
      const why = [];
      if (a.kind === 'button') {
        const ws = wordsOf(text);
        if (ws.length > 4) why.push('2–4 words');
        if (/[A-Z]{2}/.test(text) && text === text.toUpperCase() && (ws.length > 1 || text.length > 5)) why.push('sentence case, not all caps');
        if (ws.length && !VERBS.has(ws[0].toLowerCase())) why.push('start with a verb');
      } else {
        if (/^(https?:\/\/|www\.)|\.(ca|com|org|net)\/\S/i.test(text)) why.push('descriptive words, not the address');
        if (a.url) {
          const file = /\.(pdf|docx?|xlsx?|pptx?)(\?|#|$)/i.exec(a.url);
          if (file && !new RegExp('\\(' + file[1].slice(0, 3), 'i').test(text)) why.push(`say it's a file: "(${file[1].toUpperCase().replace(/X$/, '')})"`);
          const host = (/^[a-z]+:\/\/([^/?#]+)/i.exec(a.url) || [])[1];
          if (host && !/(^|\.)ucalgary\.ca$/i.test(host) && !/\([a-z0-9.-]+\.[a-z]{2,}\)/i.test(text)) why.push(`name the outside site: "(${host.replace(/^www\./, '')})"`);
          const key = text.toLowerCase();
          if (byText[key] && byText[key].url !== a.url) why.push('the same text as a link to somewhere else');
          byText[key] = byText[key] || a;
        }
      }
      if (why.length) C(a.label, `${a.kind === 'button' ? 'Button' : 'Link'} "${clip(text)}": ${why.join('; ')}.`, a.node, 'tip');
    }

    // Body text: style and word list, inclusive language, research claims, personal email addresses,
    // paragraphs and sentences, centred text, line length.
    // Per block: its text for the reading level, its style points and its widest lines, each reported once.
    const blockText = {};
    for (const p of prose) {
      const text = p.text;
      const b = blockText[p.label] = blockText[p.label] || { text: '', node: p.node, style: new Map(), wide: null };
      b.text += ' ' + text + (/[.!?]\s*$/.test(text) ? '' : '.');
      for (const [re, fix] of STYLE) { const m = re.exec(text); if (m && !b.style.has(re)) b.style.set(re, { found: m[0], fix: typeof fix === 'function' ? fix(m) : fix, node: p.node }); }
      const inclusive = INCLUSIVE.filter(([re]) => re.test(text)).map(([re, fix]) => `"${re.exec(text)[0]}" (${fix})`);
      if (inclusive.length) C(p.label, `Inclusive language: ${inclusive.join('; ')}. Check the context.`, p.node, 'check');
      const claim = CLAIMS.exec(text);
      if (claim) C(p.label, `"${claim[0]}": a claim to verify. Prefer "found", "suggests" or "indicates" unless it can be shown.`, p.node, 'check');
      const email = PERSONAL_EMAIL.exec(text);
      if (email) C(p.label, `A personal email address (${email[0]}): it needs the person's consent; a generic address or a webform is preferred.`, p.node, 'check');
      const why = [];
      if (text.split(/\n+/).some((para) => sentencesOf(para).length > 4)) why.push('a paragraph of more than 4 sentences');
      const long = sentencesOf(text).find((x) => wordsOf(x).length > 25);
      if (long) why.push(`a sentence of ${wordsOf(long).length} words ("${clip(long, 30)}")`);
      const size = typeof p.node.fontSize === 'number' ? p.node.fontSize : 0;
      const perLine = size ? p.node.width / (size * 0.5) : 0;
      if (perLine && p.node.textAlignHorizontal === 'CENTER' && text.length > 2 * perLine) why.push('centred text longer than two lines: left-align it');
      if (perLine > 90 && text.length > 90 && (!b.wide || perLine > b.wide.perLine)) b.wide = { perLine, node: p.node };
      if (why.length) C(p.label, `Plain language: ${why.join('; ')}.`, p.node, 'tip');
    }
    for (const [label, b] of Object.entries(blockText)) {
      if (b.style.size) {
        const list = [...b.style.values()].map((x) => `"${x.found}" → ${x.fix}`);
        C(label, `Style: ${list.join('; ')}${/[.)"]$/.test(list[list.length - 1]) ? '' : '.'}`, [...b.style.values()][0].node, 'tip');
      }
      if (b.wide) C(label, `Plain language: lines of about ${Math.round(b.wide.perLine)} characters: 45–90 read best.`, b.wide.node, 'tip');
      const g = grade(b.text);
      if (wordsOf(b.text).length >= 40 && Math.round(g) > 9) C(label, `Reading level about grade ${Math.round(g)}: aim for grade 8–9. Shorter sentences and everyday words bring it down.`, b.node, 'tip');
    }

    // Acronyms: spelled out where first used, as "Full Name (ACR)". Headings count; all-caps text doesn't.
    const seen = new Set();
    const ordered = headings.map((x) => ({ text: x.text, node: x.node, label: x.label })).concat(prose);
    for (const p of ordered) {
      if (p.text === p.text.toUpperCase()) continue;
      const re = /\b[A-Z][A-Z0-9]{2,5}s?\b/g; // three letters or more: two are often initials
      let m;
      while ((m = re.exec(p.text))) {
        const acr = m[0].replace(/s$/, '');
        if (seen.has(acr) || KNOWN.has(acr) || KNOWN.has(m[0])) continue;
        seen.add(acr);
        const introduced = p.text[m.index - 1] === '(' && p.text[m.index + m[0].length] === ')';
        if (!introduced) C(p.label, `"${acr}" isn't spelled out where it is first used: write the full name, then "(${acr})".`, p.node, 'tip');
      }
    }
    return title;
  }

  let frames = [];
  if (FRAME_ID) {
    for (const id of [].concat(FRAME_ID)) { const f = await figma.getNodeByIdAsync(id); if (f) frames.push(f); }
  } else {
    const page = PAGE_ID ? await figma.getNodeByIdAsync(PAGE_ID) : figma.currentPage;
    await figma.setCurrentPageAsync(page);
    for (const f of page.children) if (await isPage(f)) frames.push(f);
  }
  const checked = [];
  for (const f of frames) { const r = await checkFrame(f); checked.push({ page: f.name, id: f.id, blocks: r.blocks, build: r.build }); }
  // With OTHER_PAGES, every other page frame in the file, for the comparison across pages.
  const elsewhere = [];
  let compared = 0;
  if (OTHER_PAGES) {
    const here = new Set(frames.map((f) => f.id));
    for (const pg of figma.root.children) {
      if (typeof pg.loadAsync === 'function') await pg.loadAsync();
      for (const f of pg.children) {
        if (here.has(f.id) || !(await isPage(f))) continue;
        elsewhere.push(Object.assign(await siteOf(f), { page: pg, where: pg === figma.currentPage ? '' : pg.name }));
      }
    }
    compared = elsewhere.length;
  }
  // Pages that share a name are told apart by a number, in the order they are checked, then the file's.
  const labels = new Map();
  {
    const all = frames.concat(elsewhere.map((p) => p.frame));
    const count = {};
    for (const f of all) count[f.name] = (count[f.name] || 0) + 1;
    const n = {};
    for (const f of all) labels.set(f.id, count[f.name] > 1 ? `${f.name} (${(n[f.name] = (n[f.name] || 0) + 1)})` : f.name);
  }
  const labelOf = (frame) => labels.get(frame.id) || frame.name;
  acrossPages(elsewhere);
  for (const i of issues) i.page = labels.get(i.frame) || i.page;
  for (const c of checked) c.page = labels.get(c.id) || c.page;
  // Must fix first, then check by hand, then tips; the order the check found them within each level.
  issues.sort((a, b) => LEVELS.indexOf(a.level) - LEVELS.indexOf(b.level));
  const counts = Object.fromEntries(LEVELS.map((l) => [l, issues.filter((i) => i.level === l).length]));
  const summary = [counts.must && `${counts.must} must fix`, counts.check && `${counts.check} to check by hand`, counts.tip && `${counts.tip} ${counts.tip === 1 ? 'tip' : 'tips'}`].filter(Boolean).join(', ');
  return { rules: RULES, checked, compared, issues, counts, result: issues.length ? summary : 'Nothing to fix' };
}

// The page builder's Figma side: reads a block's designs, switches and item lists from the published
// library, makes pictures of its designs, and builds a page from an outline (a plain object the panel
// keeps). Put in front of src/main.js by scripts/build-figma-plugin.mjs, with CATALOG (src/catalog.json).
// It writes only in the designer's file: a new page frame, an instance of the library's starter page.

// ---- The library ----------------------------------------------------------------------------------

const bareName = (key) => String(key).replace(/#[^#]*$/, '');
const imported = new Map(); // key → the component set or component, once imported

// The library's component set (or single component) for a key; imported once a session.
async function libraryNode(key, single) {
  if (imported.has(key)) return imported.get(key);
  const node = single ? await figma.importComponentByKeyAsync(key) : await figma.importComponentSetByKeyAsync(key);
  imported.set(key, node);
  return node;
}

// A slot's item count from its name: "(2 to 8)", "(3 or more)", "(max 12)".
function rangeOf(name) {
  let m = /\((\d+) to (\d+)\)\s*$/.exec(name); if (m) return { min: Number(m[1]), max: Number(m[2]) };
  m = /\((\d+) or more\)\s*$/.exec(name); if (m) return { min: Number(m[1]), max: 99 };
  m = /\(max (\d+)\)\s*$/.exec(name); if (m) return { min: 1, max: Number(m[1]) };
  return null;
}
const listLabel = (name) => String(name).replace(/\s*\([^)]*\)\s*$/, '');

// The items of an item list (a slot): its visible children, or the cells of a grid inside it.
function itemsOf(slot) {
  return slot.children.filter((k) => k.visible !== false).flatMap((k) => (k.type === 'FRAME' && k.layoutMode === 'GRID' ? k.children.filter((c) => c.visible !== false) : [k]));
}
// What the panel offers for a block: its designs (variant properties; designs made for a layout column
// are left out on the page, and are the only ones in a column), its switches (boolean properties) and
// its item lists (slots), each with what the library starts it at.
function describe(node, inRegion) {
  const set = node.type === 'COMPONENT_SET' ? node : null;
  const defs = (set || node).componentPropertyDefinitions || {};
  const base = set ? set.defaultVariant : node;
  const designs = [];
  const switches = [];
  for (const [key, d] of Object.entries(defs)) {
    if (d.type === 'VARIANT') {
      const options = d.variantOptions.filter((o) => !/in a region/i.test(o));
      if (options.length > 1) designs.push({ prop: key, options, value: options.includes(d.defaultValue) ? d.defaultValue : options[0] });
    }
    if (d.type === 'BOOLEAN') switches.push({ prop: bareName(key), value: !!d.defaultValue });
  }
  switches.sort((a, b) => a.prop.localeCompare(b.prop, 'en', { numeric: true }));
  const lists = [];
  for (const s of base.findAllWithCriteria({ types: ['SLOT'] })) {
    const range = rangeOf(s.name);
    if (!range || lists.some((l) => l.name === s.name)) continue;
    lists.push({ name: s.name, label: listLabel(s.name), min: range.min, max: range.max, count: itemsOf(s).length });
  }
  return { name: (set || node).name, designs: inRegion ? [] : designs, switches, lists };
}

// The variant of a set with these designs; the default variant's for any not given.
function variantOf(set, designs) {
  if (set.type !== 'COMPONENT_SET') return set;
  const want = Object.assign({}, set.defaultVariant.variantProperties, designs || {});
  const keys = Object.keys(want);
  return set.children.find((v) => keys.every((k) => v.variantProperties[k] === want[k]))
    || set.children.find((v) => Object.keys(designs || {}).every((k) => v.variantProperties[k] === designs[k]))
    || set.defaultVariant;
}

// A picture of each option of one design, the others as the block starts: PNG bytes, 360 wide.
async function designPictures(set, prop, others) {
  const out = [];
  const def = set.componentPropertyDefinitions[prop];
  for (const option of def.variantOptions) {
    if (/in a region/i.test(option)) continue;
    const v = variantOf(set, Object.assign({}, others || {}, { [prop]: option }));
    out.push({ option, bytes: await v.exportAsync({ format: 'PNG', constraint: { type: 'WIDTH', value: 360 } }) });
  }
  return out;
}

// The columns of a layout ("33-66") and the blocks each column takes, from the region's slot property
// in the library (its preferred blocks are those blocks' In a region designs).
async function layoutColumns(columnsSet, layout) {
  const defs = columnsSet.componentPropertyDefinitions;
  const widths = String(layout).split('-').map(Number);
  const out = [];
  for (let i = 0; i < widths.length; i++) {
    const name = `Region ${i + 1} (${widths[i]}%)`;
    const key = Object.keys(defs).find((k) => bareName(k) === name);
    const allowed = [];
    for (const v of (key && defs[key].preferredValues) || []) {
      try {
        const c = await libraryNode(v.key, v.type === 'COMPONENT');
        const owner = c.parent && c.parent.type === 'COMPONENT_SET' ? c.parent : c;
        allowed.push({ key: v.key, name: owner.name, variant: c.name });
      } catch (e) { /* a preferred block the library no longer has */ }
    }
    out.push({ name, width: widths[i], allowed });
  }
  return out;
}

// A common page (a recipe in CATALOG.recipes) as an outline the panel shows and builds: each block's
// key from the catalog, with the recipe's designs, switches and counts; a layout row's columns get the
// key of their block's design for a column from the library's columns. A block the catalog or a
// column doesn't have is left out (the column keeps the library's placeholder).
async function recipeOutline(recipe, title) {
  const all = CATALOG.groups.flatMap((g) => g.blocks);
  const hero = recipe.hero || {};
  const blocks = [];
  for (const rb of recipe.blocks) {
    const info = all.find((b) => b.name === rb.name);
    if (!info) continue;
    if (info.layout) {
      const layout = (rb.designs && rb.designs.Columns) || '50-50';
      const cols = await layoutColumns(await libraryNode(info.key), layout);
      const columns = cols.map((c, i) => {
        const a = (rb.columns || [])[i] && c.allowed.find((x) => x.name === rb.columns[i]);
        return a ? { key: a.key, name: a.name, variant: a.variant, switches: {}, counts: {} } : null;
      });
      blocks.push({ key: info.key, name: info.name, component: false, layout: true, designs: { Columns: layout }, switches: {}, counts: {}, columns });
    } else {
      blocks.push({ key: info.key, name: info.name, component: !!info.component, designs: Object.assign({}, rb.designs), switches: Object.assign({}, rb.switches), counts: Object.assign({}, rb.counts) });
    }
  }
  return { title: title || '', hero: { designs: Object.assign({}, hero.designs), switches: Object.assign({}, hero.switches) }, blocks };
}

// ---- Building -----------------------------------------------------------------------------------

async function loadFonts(node) {
  const fonts = new Map();
  for (const t of node.findAllWithCriteria({ types: ['TEXT'] })) {
    for (const s of t.getStyledTextSegments(['fontName'])) fonts.set(JSON.stringify(s.fontName), s.fontName);
  }
  for (const f of fonts.values()) await figma.loadFontAsync(f);
}

const propKeyOf = (inst, name) => Object.keys(inst.componentProperties).find((k) => bareName(k) === name);

// Sets a block's switches (by their names, as the panel has them).
async function setSwitches(inst, switches) {
  const props = {};
  for (const [name, value] of Object.entries(switches || {})) {
    const k = propKeyOf(inst, name);
    if (k && inst.componentProperties[k].type === 'BOOLEAN' && inst.componentProperties[k].value !== value) props[k] = !!value;
  }
  if (Object.keys(props).length) { inst.setProperties(props); await loadFonts(inst); }
}

// Gives an item list this many items: copies of its last item, or the last ones removed. In a grid
// (Cards) the items go by their cells, a copy is put in the next empty cell (a copy keeps its
// original's cell), and the rows follow the count, so no gap and no empty row is left.
async function setCount(inst, listName, count) {
  const slot = inst.findAllWithCriteria({ types: ['SLOT'] }).find((s) => s.name === listName);
  if (!slot) return;
  const range = rangeOf(listName) || { min: 0, max: 99 };
  const want = Math.max(range.min, Math.min(range.max, count));
  const grid = slot.children.find((k) => k.type === 'FRAME' && k.layoutMode === 'GRID');
  const cols = grid ? grid.gridColumnCount || 1 : 1;
  const ordered = () => {
    const items = itemsOf(slot);
    return grid ? items.sort((a, b) => a.gridRowAnchorIndex * cols + a.gridColumnAnchorIndex - (b.gridRowAnchorIndex * cols + b.gridColumnAnchorIndex)) : items;
  };
  let items = ordered();
  if (!items.length || items.length === want) return;
  if (grid && want > items.length) grid.gridRowCount = Math.max(grid.gridRowCount, Math.ceil(want / cols));
  while (items.length < want) {
    const n = items.length;
    const copy = items[n - 1].clone();
    (grid || slot).appendChild(copy);
    if (grid) copy.setGridChildPosition(Math.floor(n / cols), n % cols);
    items = ordered();
  }
  while (items.length > want) { items[items.length - 1].remove(); items = ordered(); }
  if (grid) grid.gridRowCount = Math.max(1, Math.ceil(items.length / cols));
  await loadFonts(inst);
}

// One block of the outline as an instance, put where it goes (place), then given its switches and
// item counts. If it can't be placed, it is removed, so nothing is left loose on the canvas.
async function makeBlock(block, place) {
  const lib = await libraryNode(block.key, block.component);
  const inst = variantOf(lib, block.designs).createInstance();
  try {
    await loadFonts(inst);
    place(inst);
  } catch (error) {
    inst.remove();
    throw error;
  }
  await setSwitches(inst, block.switches);
  for (const [list, count] of Object.entries(block.counts || {})) await setCount(inst, list, count);
  return inst;
}

// Where a new page goes: to the right of everything on the Figma page, level with its top.
function freeSpot(page) {
  let right = 0, top = 0, first = true;
  for (const n of page.children) {
    if (!('x' in n)) continue;
    right = Math.max(right, n.x + n.width);
    top = first ? n.y : Math.min(top, n.y);
    first = false;
  }
  return { x: first ? 0 : Math.round(right + 200), y: Math.round(top) };
}

// Builds the outline into a new page on the open Figma page and returns it. If a step fails, the
// half-built page is removed and the error names the block it stopped at.
// outline: { title, hero: { designs, switches }, blocks: [{ key, component, designs, switches, counts }
//   or a layout row: { key, layout: true, designs: { Columns: '33-66' }, columns: [block or null] }] }
async function buildPage(outline, progress) {
  const say = progress || (() => {});
  say('Getting the starter page from the library…');
  const starter = await libraryNode(CATALOG.starter.key, true);
  const spot = freeSpot(figma.currentPage);
  const page = starter.createInstance();
  page.x = spot.x; page.y = spot.y;
  let at = 'the starter page';
  try {
    await fillPage(page, outline, say, (where) => { at = where; });
    return page;
  } catch (error) {
    page.remove();
    throw new Error(`The page was not built: ${at} failed (${String(error && error.message ? error.message : error)}).`);
  }
}

async function fillPage(page, outline, say, stage) {
  const title = String(outline.title || '').trim();
  page.name = title || 'New page';
  await loadFonts(page);

  // The hero: its design, switches and the page's title.
  stage('the Hero');
  const heroNode = page.children.find((c) => c.type === 'INSTANCE' && c.name === CATALOG.hero.name);
  if (heroNode && outline.hero) {
    const heroSet = await libraryNode(CATALOG.hero.key);
    const want = variantOf(heroSet, outline.hero.designs);
    const props = {};
    for (const [k, v] of Object.entries(want.variantProperties || {})) { const pk = propKeyOf(heroNode, k); if (pk && heroNode.componentProperties[pk].value !== v) props[pk] = v; }
    if (Object.keys(props).length) { heroNode.setProperties(props); await loadFonts(heroNode); }
    await setSwitches(heroNode, outline.hero.switches);
    const tk = Object.keys(heroNode.componentProperties).find((k) => /^Title\b/.test(bareName(k)) && heroNode.componentProperties[k].type === 'TEXT');
    if (tk && title) heroNode.setProperties({ [tk]: title });
  }

  // The blocks, in order, in the starter page's Blocks slot.
  const slot = page.findAllWithCriteria({ types: ['SLOT'] }).find((s) => s.name === 'Blocks' && s.parent === page);
  for (const c of [...slot.children]) c.remove();
  const blocks = outline.blocks || [];
  for (let i = 0; i < blocks.length; i++) {
    const b = blocks[i];
    const name = String(b.name || '').replace(/^(Block|Layout)\//, '').replace(/^Columns$/, 'Blocks side by side');
    stage(`block ${i + 1}, ${name}`);
    say(`Placing ${i + 1} of ${blocks.length}: ${name}…`);
    if (b.layout) {
      const row = await makeBlock({ key: b.key, designs: b.designs }, (inst) => slot.appendChild(inst));
      const regions = row.findAllWithCriteria({ types: ['SLOT'] }).filter((s) => /\(\d+%\)\s*$/.test(s.name) && s.visible !== false);
      regions.sort((a, b2) => a.name.localeCompare(b2.name, 'en', { numeric: true }));
      for (let r = 0; r < regions.length; r++) {
        const chosen = (b.columns || [])[r];
        if (!chosen) continue;
        stage(`block ${i + 1}, ${name}: column ${r + 1}`);
        await makeBlock({ key: chosen.key, component: true, switches: chosen.switches, counts: chosen.counts }, (inst) => {
          for (const c of [...regions[r].children]) c.remove();
          regions[r].appendChild(inst);
          inst.layoutSizingHorizontal = 'FILL';
        });
      }
      await loadFonts(row);
    } else {
      await makeBlock(b, (inst) => slot.appendChild(inst));
    }
  }
  return page;
}

// The Page builder plugin: the panel (ui.html) keeps the outline; this side reads the library, makes
// pictures of designs, builds the page and runs the Page check on it (runCheck, from
// scripts/figma-check-page.js, and src/builder.js are put in front of this file by
// scripts/build-figma-plugin.mjs). The draft outline and the block pictures are kept on this computer
// (figma.clientStorage), never in the file.
figma.showUI(__html__, { width: 420, height: 680, themeColors: true });

const fileName = figma.fileKey || figma.root.name;
const DRAFT = 'draft:' + fileName;
const THUMB = 'thumb:';
const THUMB_DAYS = 14; // pictures of blocks are made again after this, in case the library changed

const store = {
  get: async (key, fallback) => { try { const v = await figma.clientStorage.getAsync(key); return v === undefined ? fallback : v; } catch (e) { return fallback; } },
  set: async (key, value) => { try { await figma.clientStorage.setAsync(key, value); } catch (e) { /* the panel still works */ } },
};

// One request at a time: imports and pictures are slow, and the panel asks for many at once.
let queue = Promise.resolve();
const inTurn = (fn) => { queue = queue.then(fn, fn); return queue; };

function problem(error) {
  const text = String(error && error.message ? error.message : error);
  if (/import|library|not found|access|published/i.test(text)) return 'The UCWC library could not be reached: in Assets → Libraries, check that the UCWS Wireframing Toolkit is turned on for this file. (' + text + ')';
  return text;
}

const pictures = new Map(); // key|prop|others → [{ option, bytes }]

async function handle(m) {
  try {
    if (m.type === 'describe') {
      const node = await libraryNode(m.key, m.component);
      figma.ui.postMessage({ type: 'described', key: m.key, details: describe(node, m.inRegion) });
    }
    if (m.type === 'pictures') {
      const id = m.key + '|' + m.prop + '|' + JSON.stringify(m.others || {});
      if (!pictures.has(id)) pictures.set(id, await designPictures(await libraryNode(m.key), m.prop, m.others));
      figma.ui.postMessage({ type: 'pictures', key: m.key, prop: m.prop, pictures: pictures.get(id) });
    }
    // A block's picture: as it starts (kept on this computer), or with the designs chosen for it.
    if (m.type === 'thumb') {
      const plain = !m.designs;
      const kept = plain ? await store.get(THUMB + m.key, null) : null;
      let bytes = kept && Date.now() - kept.at < THUMB_DAYS * 864e5 ? kept.bytes : null;
      if (!bytes) {
        const node = await libraryNode(m.key, m.component);
        bytes = await variantOf(node, m.designs).exportAsync({ format: 'PNG', constraint: { type: 'WIDTH', value: 360 } });
        if (plain) await store.set(THUMB + m.key, { bytes, at: Date.now() });
      }
      figma.ui.postMessage({ type: 'thumb', id: m.id || m.key, bytes });
    }
    if (m.type === 'columns') {
      const set = await libraryNode(CATALOG.columns.key);
      figma.ui.postMessage({ type: 'columns', layout: m.layout, columns: await layoutColumns(set, m.layout) });
    }
    if (m.type === 'recipe') {
      const recipe = (CATALOG.recipes || []).find((r) => r.name === m.name);
      if (!recipe) throw new Error('There is no common page called “' + m.name + '”.');
      figma.ui.postMessage({ type: 'recipe', name: m.name, outline: await recipeOutline(recipe, m.title) });
    }
    if (m.type === 'build') {
      const page = await buildPage(m.outline, (text) => figma.ui.postMessage({ type: 'progress', text }));
      figma.currentPage.selection = [page];
      figma.viewport.scrollAndZoomIntoView([page]);
      figma.ui.postMessage({ type: 'progress', text: 'Checking the page…' });
      const result = await runCheck(null, [page.id], false);
      figma.ui.postMessage({
        type: 'built', page: page.name, id: page.id, result: result.result, counts: result.counts,
        issues: result.issues.map((i) => ({ level: i.level, where: i.where, message: i.message, id: i.id })),
      });
    }
  } catch (error) {
    figma.ui.postMessage({ type: 'error', request: m.type, key: m.key, message: problem(error) });
  }
}

figma.ui.onmessage = (m) => {
  if (m.type === 'save') return store.set(DRAFT, m.outline);
  if (m.type === 'show') {
    return figma.getNodeByIdAsync(m.id).then((node) => {
      if (!node) { figma.notify('That layer is no longer there.'); return; }
      figma.currentPage.selection = [node];
      figma.viewport.scrollAndZoomIntoView([node]);
    });
  }
  return inTurn(() => handle(m));
};

(async function start() {
  figma.ui.postMessage({ type: 'catalog', catalog: CATALOG, draft: await store.get(DRAFT, null), file: figma.root.name });
})();
