// Built by scripts/build-figma-plugin.mjs from scripts/figma-check-page.js and src/main.js.
// Do not edit: change those files and run `npm run build:figma-plugin`.

// The page check. PAGE_ID: a page to check (null: the page that is open). FRAME_ID: one page frame.
async function runCheck(PAGE_ID, FRAME_ID) {
  const issues = [];
  // One thing to fix: the page frame it is on (its name, and its id as `frame`), where, what to do, and
  // the layer to look at (`id`).
  const add = (frame, where, message, node) => issues.push({ page: frame.name, frame: frame.id, where, message, id: (node || frame).id });
  const setOf = async (inst) => { const m = await inst.getMainComponentAsync(); if (!m) return null; return m.parent && m.parent.type === 'COMPONENT_SET' ? m.parent : m; };
  const bare = (key) => key.replace(/#[^#]*$/, '');
  const maxOf = (name) => { const m = /\(max ([\d,]+)\)\s*$/.exec(bare(name)); return m ? Number(m[1].replace(/,/g, '')) : null; };
  const countOf = (name) => {
    let m = /\((\d+) to (\d+)\)\s*$/.exec(name); if (m) return { min: Number(m[1]), max: Number(m[2]) };
    m = /\((\d+) or more\)\s*$/.exec(name); if (m) return { min: Number(m[1]), max: Infinity };
    m = /\(max (\d+)\)\s*$/.exec(name); if (m) return { min: 0, max: Number(m[1]) };
    return null;
  };
  const unescape = (s) => String(s || '').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  const fitsOf = (set) => { const m = /Fits:\s*([^\n.]+)/.exec(unescape(set.description)); return m ? (m[1].match(/\d+/g) || []).map(Number) : [100]; };

  async function checkLimits(frame, node, label) {
    // The instance's own text properties.
    if (node.type === 'INSTANCE') {
      for (const [key, prop] of Object.entries(node.componentProperties)) {
        if (prop.type !== 'TEXT') continue;
        const max = maxOf(key);
        if (max && String(prop.value).length > max) add(frame, label, `${bare(key)}: ${String(prop.value).length} characters, the limit is ${max}.`, node);
      }
      const max = maxOf(node.name);
      if (max) {
        const t = node.findOne((n) => n.type === 'TEXT' && n.visible);
        if (t && t.characters.length > max) add(frame, label, `${node.name}: ${t.characters.length} characters, the limit is ${max}.`, t);
      }
    }
    if (node.type === 'TEXT' && node.visible) {
      const max = maxOf(node.name);
      if (max && node.characters.length > max) add(frame, label, `${node.name}: ${node.characters.length} characters, the limit is ${max}.`, node);
    }
    if ('children' in node) for (const c of node.children) if (c.visible) await checkLimits(frame, c, label);
  }

  // A list can hold its items in a grid frame (Cards: "Card grid"), so that a row's cards share a height
  // and a new row comes by itself. Figma keeps each item in its cell, so deleting one leaves a gap.
  function gridItems(frame, grid, what) {
    const kids = grid.children.filter((k) => k.visible);
    const cols = grid.gridColumnCount;
    const cells = kids.map((k) => k.gridRowAnchorIndex * cols + k.gridColumnAnchorIndex).sort((x, y) => x - y);
    if (cells.some((cell, i) => cell !== i)) add(frame, what, 'A gap between the items: drag each item after the gap one cell back, so the rows fill from the left.', grid);
    else if (grid.gridRowCount > Math.max(1, Math.ceil(kids.length / cols))) add(frame, what, `An empty row is left at the end: select "${grid.name}" and lower its row count.`, grid);
    return kids;
  }

  // A block's item slots: the count its name allows, and only the items its preferred values list.
  // An item can hold slots of its own (an accordion section's sub-sections), so this follows them.
  async function checkItems(frame, inst, label) {
    if (!inst.findAllWithCriteria({ types: ['SLOT'] }).length) return;
    const set = await setOf(inst);
    const defs = set ? set.componentPropertyDefinitions : {};
    const walk = async (node) => {
      for (const c of node.children) {
        if (!c.visible) continue;
        if (c.type === 'SLOT') {
          const key = Object.keys(defs).find((k) => defs[k].type === 'SLOT' && bare(k) === c.name);
          const allowed = key ? (defs[key].preferredValues || []).map((p) => p.key) : [];
          const what = `${label} → ${c.name.replace(/\s*\([^)]*\)\s*$/, '')}`;
          const items = c.children.filter((k) => k.visible).flatMap((k) => (k.type === 'FRAME' && k.layoutMode === 'GRID' ? gridItems(frame, k, what) : [k]));
          const range = countOf(c.name);
          if (range && items.length < range.min) add(frame, what, `${items.length} here: at least ${range.min}.`, c);
          if (range && items.length > range.max) add(frame, what, `${items.length} here: at most ${range.max}.`, c);
          for (const item of items) {
            const itemSet = item.type === 'INSTANCE' ? await setOf(item) : null;
            if (!itemSet || (allowed.length && !allowed.includes(itemSet.key))) add(frame, what, `"${item.name}" is not one of this block's items: it was drawn by hand, detached or taken from another block.`, item);
            else await checkItems(frame, item, what);
          }
        } else if (c.type === 'INSTANCE') await checkItems(frame, c, label);
        else if ('children' in c) await walk(c);
      }
    };
    await walk(inst);
  }

  // A block swapped into a region arrives in its full-width design, whose content is wider than the
  // column: the first visible layer that reaches past the region's sides.
  function widerThan(node, slot) {
    const s = slot.absoluteBoundingBox;
    let found = false;
    const walk = (n) => {
      if (found || !n.visible) return;
      const b = n.absoluteBoundingBox;
      if (b && b.width > 0 && (b.x < s.x - 1 || b.x + b.width > s.x + s.width + 1)) { found = true; return; }
      if ('children' in n) n.children.forEach(walk);
    };
    walk(node);
    return found;
  }

  async function checkBlock(frame, node, regionWidth, slot) {
    const set = node.type === 'INSTANCE' ? await setOf(node) : null;
    const name = set ? set.name : null;
    if (!name || !(name.startsWith('Block/') || name.startsWith('Layout/'))) {
      if (name && /^_?Layout part\/Empty region/.test(name)) add(frame, slot ? slot.name : node.name, 'An empty-region placeholder is still here: delete it, or swap it for a block.', node);
      else add(frame, node.name, 'Not a block: it was drawn by hand or detached, so it cannot be built in Drupal.', node);
      return null;
    }
    if (name === 'Layout/Columns') {
      if (regionWidth) { add(frame, node.name, 'A layout row inside a region: Drupal has no nested layouts.', node); return name; }
      for (const s of node.findAllWithCriteria({ types: ['SLOT'] })) {
        if (!/\(\d+%\)\s*$/.test(s.name)) continue; // a block's own item slot, checked with its block
        const w = Number((/\((\d+)%\)/.exec(s.name) || [])[1]);
        if (!s.children.length) add(frame, s.name, 'This region is empty.', s);
        for (const child of s.children) await checkBlock(frame, child, w, s);
      }
      return name;
    }
    const short = name.replace('Block/', '');
    const label = regionWidth ? `${slot.name} → ${short}` : short;
    if (regionWidth) {
      const fits = fitsOf(set);
      if (!fits.includes(regionWidth)) add(frame, label, `${short} doesn't fit a ${regionWidth}% column (it fits ${fits.map((f) => f + '%').join(', ')}).`, node);
      else if (Math.abs(node.width - slot.width) > 1) add(frame, label, `${short} is ${Math.round(node.width)} wide in a ${Math.round(slot.width)} region: choose its In a region design and set its width to Fill.`, node);
      else if (widerThan(node, slot)) add(frame, label, `${short}'s content is wider than its column: choose its In a region design.`, node);
    } else if (Math.abs(node.width - 1440) > 1) add(frame, short, `${short} is ${Math.round(node.width)} wide: a block on the page is 1440 wide.`, node);
    await checkItems(frame, node, label);
    await checkLimits(frame, node, label);
    return name;
  }

  async function checkFrame(frame) {
    const names = [];
    for (const child of frame.children) names.push(await checkBlock(frame, child, 0, null));
    if (names[0] !== 'Block/Header') add(frame, 'Page', 'The Header comes first.', frame.children[0]);
    if (names[names.length - 1] !== 'Block/Footer') add(frame, 'Page', 'The Footer comes last.', frame.children[frame.children.length - 1]);
    const heroes = names.filter((n) => n === 'Block/Hero CTA').length;
    if (heroes !== 1) add(frame, 'Page', `A page has one Hero CTA; this one has ${heroes}.`);
    else if (names[1] !== 'Block/Hero CTA') add(frame, 'Page', 'The Hero CTA comes right after the Header.', frame.children[1]);
    for (const limited of ['Block/Trio CTA', 'Block/Image with text']) {
      let run = 0;
      names.forEach((n, i) => { run = n === limited ? run + 1 : 0; if (run === 3) add(frame, 'Page', `More than two ${limited.replace('Block/', '')} blocks in a row.`, frame.children[i]); });
    }
    // Image banners are taller on a page without a full-bleed hero (blocks.md → Banner, Page mode): every
    // hero is full-bleed but the mini image hero.
    const prop = (inst, name) => { const k = Object.keys(inst.componentProperties).find((key) => bare(key) === name); return k ? inst.componentProperties[k].value : undefined; };
    const hero = frame.children.find((c, i) => names[i] === 'Block/Hero CTA');
    const fullBleedHero = hero ? !/^Mini/.test(String(prop(hero, 'Design'))) : false;
    frame.children.forEach((child, i) => {
      if (names[i] !== 'Block/Banner') return;
      const design = String(prop(child, 'Design'));
      const taller = prop(child, 'Page without a full-bleed hero');
      if (!/^Image/.test(design) || design === 'Image only' || taller === undefined) return;
      if (fullBleedHero && taller) add(frame, 'Banner', 'This page starts with a full-bleed hero, so its image banners are the shorter ones: switch off "Page without a full-bleed hero".', child);
      if (!fullBleedHero && !taller) add(frame, 'Banner', 'This page has a mini hero or none, so its image banners are taller: switch on "Page without a full-bleed hero".', child);
    });
    if (frame.layoutMode !== 'VERTICAL' || frame.itemSpacing !== 0) add(frame, 'Page', 'The page frame should be a vertical auto layout with no gap, so blocks stack as on the site.');
    return names.length;
  }

  let frames = [];
  if (FRAME_ID) frames = [await figma.getNodeByIdAsync(FRAME_ID)];
  else {
    const page = PAGE_ID ? await figma.getNodeByIdAsync(PAGE_ID) : figma.currentPage;
    await figma.setCurrentPageAsync(page);
    for (const f of page.children) {
      if (f.type !== 'FRAME' || Math.abs(f.width - 1440) > 1) continue;
      let hasHeader = false;
      for (const c of f.children) if (c.type === 'INSTANCE' && ((await setOf(c)) || {}).name === 'Block/Header') hasHeader = true;
      if (hasHeader) frames.push(f);
    }
  }
  const checked = [];
  for (const f of frames) checked.push({ page: f.name, id: f.id, blocks: await checkFrame(f) });
  return { checked, issues, result: issues.length ? `${issues.length} thing(s) to fix` : 'Nothing to fix' };
}

// The plugin around the page check: runs it on the page that is open (or on the page frames that are
// selected), shows what it found in a panel, and selects a finding's layer when it is clicked.
// runCheck() is scripts/figma-check-page.js, put in front of this file by scripts/build-figma-plugin.mjs.
// It changes nothing in the file.
figma.showUI(__html__, { width: 380, height: 540, themeColors: true });

async function run() {
  figma.ui.postMessage({ type: 'busy' });
  try {
    const picked = figma.currentPage.selection.filter(function (n) {
      return n.type === 'FRAME' && n.parent && n.parent.type === 'PAGE' && Math.abs(n.width - 1440) <= 1;
    });
    let checked = [];
    let issues = [];
    if (picked.length) {
      for (const frame of picked) {
        const one = await runCheck(null, frame.id);
        checked = checked.concat(one.checked);
        issues = issues.concat(one.issues);
      }
    } else {
      const all = await runCheck(null, null);
      checked = all.checked;
      issues = all.issues;
    }
    figma.ui.postMessage({ type: 'result', page: figma.currentPage.name, selection: picked.length > 0, checked: checked, issues: issues });
  } catch (error) {
    figma.ui.postMessage({ type: 'error', message: String(error && error.message ? error.message : error) });
  }
}

figma.ui.onmessage = async function (message) {
  if (message.type === 'run') await run();
  if (message.type === 'close') figma.closePlugin();
  if (message.type === 'show') {
    const node = await figma.getNodeByIdAsync(message.id);
    if (!node) { figma.notify('That layer is no longer on the page: check again.'); return; }
    try {
      figma.currentPage.selection = [node];
      figma.viewport.scrollAndZoomIntoView([node]);
    } catch (error) {
      figma.notify('Could not select that layer.');
    }
  }
};

run();
