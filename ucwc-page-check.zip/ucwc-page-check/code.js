// Built by scripts/build-figma-plugin.mjs from scripts/figma-check-page.js, src/report.js and src/main.js.
// Do not edit: change those files and run `npm run build:figma-plugin`.
// Rules: version 3 (2026-11-09), fingerprint f2f306b5e899

// The page check. PAGE_ID: a page to check (null: the page that is open). FRAME_ID: page frames' ids.
async function runCheck(PAGE_ID, FRAME_ID) {
  const issues = [];
  // The rules' version: raise it, and set the date, with every change to the rules (the plugin shows it,
  // so a designer can tell whether their copy is current). scripts/build-figma-plugin.mjs refuses to build
  // when the rules changed and the version didn't.
  const RULES = { version: 3, date: '2026-11-09' };
  // One finding: the page frame it is on (its name, and its id as `frame`), where, what to do, the layer
  // to look at (`id`), how much it matters (`level`) and which part of the check found it (`section`).
  //   level:   'must' (must fix: the page can't be built as designed), 'check' (check by hand: the check
  //            can't decide), 'tip' (worth a look)
  //   section: 'structure' (blocks, layout rows, items, limits) or 'content' (the words on the page)
  const LEVELS = ['must', 'check', 'tip'];
  const add = (frame, where, message, node, level = 'must', section = 'structure') => issues.push({ page: frame.name, frame: frame.id, where, message, id: (node || frame).id, level, section });
  const setOf = async (inst) => { const m = await inst.getMainComponentAsync(); if (!m) return null; return m.parent && m.parent.type === 'COMPONENT_SET' ? m.parent : m; };
  const bare = (key) => key.replace(/#[^#]*$/, '');
  const maxOf = (name) => { const m = /\(max ([\d,]+)\)\s*$/.exec(bare(name)); return m ? Number(m[1].replace(/,/g, '')) : null; };
  const countOf = (name) => {
    let m = /\((\d+) to (\d+)\)\s*$/.exec(name); if (m) return { min: Number(m[1]), max: Number(m[2]) };
    m = /\((\d+) or more\)\s*$/.exec(name); if (m) return { min: Number(m[1]), max: Infinity };
    m = /\(max (\d+)\)\s*$/.exec(name); if (m) return { min: 0, max: Number(m[1]) };
    return null;
  };
  const unescape = (s) => String(s || '').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  // Blocks of the Block Library the design system has only at `spec` (blocks.md → Current blocks): no
  // component yet. scripts/check-page-check.mjs fails when this list and blocks.md differ.
  const SPEC_BLOCKS = ['Animation', 'Campus map', 'Important dates', 'Marketo', 'Price list', 'Progress', 'Schedule'];
  const specName = (name) => SPEC_BLOCKS.find((b) => b.toLowerCase() === String(name).replace(/^Block\//, '').trim().toLowerCase());
  const fitsOf = (set) => { const m = /Fits:\s*([^\n.]+)/.exec(unescape(set.description)); return m ? (m[1].match(/\d+/g) || []).map(Number) : [100]; };

  async function checkLimits(frame, node, label) {
    // The instance's own text properties.
    if (node.type === 'INSTANCE') {
      for (const [key, prop] of Object.entries(node.componentProperties)) {
        if (prop.type !== 'TEXT') continue;
        const max = maxOf(key);
        if (max && String(prop.value).length > max) add(frame, label, `${bare(key)}: ${String(prop.value).length} characters, the limit is ${max}.`, node);
      }
      const max = maxOf(node.name);
      if (max) {
        const t = node.findOne((n) => n.type === 'TEXT' && n.visible);
        if (t && t.characters.length > max) add(frame, label, `${node.name}: ${t.characters.length} characters, the limit is ${max}.`, t);
      }
    }
    if (node.type === 'TEXT' && node.visible) {
      const max = maxOf(node.name);
      if (max && node.characters.length > max) add(frame, label, `${node.name}: ${node.characters.length} characters, the limit is ${max}.`, node);
    }
    if ('children' in node) for (const c of node.children) if (c.visible) await checkLimits(frame, c, label);
  }

  // A list can hold its items in a grid frame (Cards: "Card grid"), so that a row's cards share a height
  // and a new row comes by itself. Figma keeps each item in its cell, so deleting one leaves a gap.
  function gridItems(frame, grid, what) {
    const kids = grid.children.filter((k) => k.visible);
    const cols = grid.gridColumnCount;
    const cells = kids.map((k) => k.gridRowAnchorIndex * cols + k.gridColumnAnchorIndex).sort((x, y) => x - y);
    if (cells.some((cell, i) => cell !== i)) add(frame, what, 'A gap between the items: drag each item after the gap one cell back, so the rows fill from the left.', grid);
    else if (grid.gridRowCount > Math.max(1, Math.ceil(kids.length / cols))) add(frame, what, `An empty row is left at the end: select "${grid.name}" and lower its row count.`, grid);
    return kids;
  }

  // A block's item slots: the count its name allows, and only the items its preferred values list.
  // An item can hold slots of its own (an accordion section's sub-sections), so this follows them.
  async function checkItems(frame, inst, label) {
    if (!inst.findAllWithCriteria({ types: ['SLOT'] }).length) return;
    const set = await setOf(inst);
    const defs = set ? set.componentPropertyDefinitions : {};
    const walk = async (node) => {
      for (const c of node.children) {
        if (!c.visible) continue;
        if (c.type === 'SLOT') {
          const key = Object.keys(defs).find((k) => defs[k].type === 'SLOT' && bare(k) === c.name);
          const allowed = key ? (defs[key].preferredValues || []).map((p) => p.key) : [];
          const what = `${label} → ${c.name.replace(/\s*\([^)]*\)\s*$/, '')}`;
          const items = c.children.filter((k) => k.visible).flatMap((k) => (k.type === 'FRAME' && k.layoutMode === 'GRID' ? gridItems(frame, k, what) : [k]));
          const range = countOf(c.name);
          if (range && items.length < range.min) add(frame, what, `${items.length} here: at least ${range.min}.`, c);
          if (range && items.length > range.max) add(frame, what, `${items.length} here: at most ${range.max}.`, c);
          for (const item of items) {
            const itemSet = item.type === 'INSTANCE' ? await setOf(item) : null;
            if (!itemSet || (allowed.length && !allowed.includes(itemSet.key))) add(frame, what, `"${item.name}" is not one of this block's items: it was drawn by hand, detached or taken from another block.`, item);
            else await checkItems(frame, item, what);
          }
        } else if (c.type === 'INSTANCE') await checkItems(frame, c, label);
        else if ('children' in c) await walk(c);
      }
    };
    await walk(inst);
  }

  // A block swapped into a region arrives in its full-width design, whose content is wider than the
  // column: the first visible layer that reaches past the region's sides.
  function widerThan(node, slot) {
    const s = slot.absoluteBoundingBox;
    let found = false;
    const walk = (n) => {
      if (found || !n.visible) return;
      const b = n.absoluteBoundingBox;
      if (b && b.width > 0 && (b.x < s.x - 1 || b.x + b.width > s.x + s.width + 1)) { found = true; return; }
      if ('children' in n) n.children.forEach(walk);
    };
    walk(node);
    return found;
  }

  const propOf = (inst, name) => { const k = Object.keys(inst.componentProperties || {}).find((key) => bare(key) === name); return k ? inst.componentProperties[k].value : undefined; };

  // What only a person can check, where the block shows it (blocks.md; content.md → Images and media).
  function reminders(frame, node, name, label) {
    const design = String(propOf(node, 'Design') || '');
    const R = (message) => add(frame, label, message, node, 'check');
    const photoText = 'White text over a photo: check its contrast by hand against the lightest part of the photo under the text (4.5:1, and 3:1 for a heading), even with the scrim.';
    if (name === 'Block/Hero CTA' && /^Overlay/.test(design)) R(photoText);
    if (name === 'Block/Banner' && /^Image/.test(design)) {
      if (design === 'Image only') R('The words are in the picture: give the image alt text that says what the picture says.');
      else R(photoText);
    }
    if (name === 'Block/Sidekick CTA') R('The box sits over the photo: check it doesn\'t cover the photo\'s focal point.');
    if (name === 'Block/Streaming media') {
      if (/^Video/.test(design)) R('A video needs captions: check them, and edit automatic captions for accuracy.');
      else if (/^Audio/.test(design)) R('A podcast or audio needs a transcript, on the page below the player or linked.');
    }
  }

  // The page's build list (Phase 6): each block in order, with its designs and switches (variant and
  // boolean properties), its item lists (how many in each) and its text, layer by layer; a layout row with
  // its regions and their blocks. The Header and Footer carry the site's own, so only their switches and
  // the Header's navigation.
  async function buildItem(node) {
    const set = await setOf(node);
    const name = set ? set.name : node.name;
    const props = {};
    for (const [key, p] of Object.entries(node.componentProperties || {})) {
      if (p.type === 'VARIANT' || p.type === 'BOOLEAN') props[bare(key)] = p.value;
    }
    const item = { block: name.replace(/^Block\//, ''), id: node.id, properties: props };
    if (/^Layout\//.test(name)) {
      item.regions = [];
      for (const s of node.findAllWithCriteria({ types: ['SLOT'] }).filter((x) => /\(\d+%\)\s*$/.test(x.name))) {
        const blocks = [];
        for (const k of s.children) if (k.visible && k.type === 'INSTANCE') blocks.push(await buildItem(k));
        item.regions.push({ region: s.name, blocks });
      }
      return item;
    }
    if (name === 'Block/Header') {
      item.navigation = (await navOf(node)).map((n) => n.label);
      return item;
    }
    if (name === 'Block/Footer') return item;
    const lists = node.findAllWithCriteria({ types: ['SLOT'] }).filter((s) => shown(s, node));
    if (lists.length) item.lists = lists.map((s) => ({ list: s.name.replace(/\s*\([^)]*\)\s*$/, ''), items: s.children.filter((k) => k.visible).flatMap((k) => (k.type === 'FRAME' && k.layoutMode === 'GRID' ? k.children.filter((c) => c.visible) : [k])).length }));
    item.text = node.findAllWithCriteria({ types: ['TEXT'] }).filter((t) => shown(t, node) && t.characters.trim())
      .map((t) => ({ layer: t.name.replace(/\s*\(max [\d,]+\)\s*$/, ''), text: t.characters }));
    return item;
  }

  // The Header's navigation: its top-level items' labels, in order.
  async function navOf(header) {
    const nav = [];
    for (const i of header.findAllWithCriteria({ types: ['INSTANCE'] })) {
      if (!shown(i, header)) continue;
      const set = await setOf(i);
      if (set && /nav item$/.test(set.name)) nav.push({ label: String(propOf(i, 'Label') || ''), node: i });
    }
    return nav;
  }

  // The page's blocks (not layout rows) in page order, regions left to right: the content checks read them.
  let placed = [];

  async function checkBlock(frame, node, regionWidth, slot) {
    const set = node.type === 'INSTANCE' ? await setOf(node) : null;
    const name = set ? set.name : null;
    if (!name || !(name.startsWith('Block/') || name.startsWith('Layout/'))) {
      if (name && /^_?Layout part\/Empty region/.test(name)) add(frame, slot ? slot.name : node.name, 'An empty-region placeholder is still here: delete it, or swap it for a block.', node);
      else if (name === 'Annotation') add(frame, node.name, 'An annotation inside the page: move it beside the page frame, where it is not part of the page.', node);
      else if (specName(node.name)) add(frame, node.name, `${specName(node.name)} is a Block Library block this file doesn't have yet (blocks.md: spec), so it is drawn by hand: check it against its Block Library page before it is built.`, node, 'tip');
      else add(frame, node.name, 'Not a block: it was drawn by hand or detached, so it cannot be built in Drupal.', node);
      return null;
    }
    if (name === 'Layout/Columns') {
      if (regionWidth) { add(frame, node.name, 'A layout row inside a region: Drupal has no nested layouts.', node); return name; }
      for (const s of node.findAllWithCriteria({ types: ['SLOT'] })) {
        if (!/\(\d+%\)\s*$/.test(s.name)) continue; // a block's own item slot, checked with its block
        const w = Number((/\((\d+)%\)/.exec(s.name) || [])[1]);
        if (!s.children.length) add(frame, s.name, 'This region is empty.', s);
        for (const child of s.children) await checkBlock(frame, child, w, s);
      }
      return name;
    }
    const short = name.replace('Block/', '');
    const label = regionWidth ? `${slot.name} → ${short}` : short;
    if (specName(short)) add(frame, label, `${short} is at spec in the design system (blocks.md): it has no code yet, so check it against its Block Library page.`, node, 'tip');
    reminders(frame, node, name, label);
    if (regionWidth) {
      const fits = fitsOf(set);
      if (!fits.includes(regionWidth)) add(frame, label, `${short} doesn't fit a ${regionWidth}% column (it fits ${fits.map((f) => f + '%').join(', ')}).`, node);
      else if (Math.abs(node.width - slot.width) > 1) add(frame, label, `${short} is ${Math.round(node.width)} wide in a ${Math.round(slot.width)} region: choose its In a region design and set its width to Fill.`, node);
      else if (widerThan(node, slot)) add(frame, label, `${short}'s content is wider than its column: choose its In a region design.`, node);
    } else if (Math.abs(node.width - 1440) > 1) add(frame, short, `${short} is ${Math.round(node.width)} wide: a block on the page is 1440 wide.`, node);
    await checkItems(frame, node, label);
    await checkLimits(frame, node, label);
    placed.push({ node, name, label });
    return name;
  }

  // A page's blocks in order: its own layers, with the template's slot (Blocks) opened in place.
  function pageBlocks(frame) {
    return frame.children.flatMap((c) => (c.type === 'SLOT' ? c.children.filter((k) => k.visible) : [c]));
  }

  async function isPage(f) {
    if (Math.abs(f.width - 1440) > 1) return false;
    if (f.type === 'INSTANCE') return /^Page\//.test(((await setOf(f)) || {}).name || '');
    if (f.type !== 'FRAME') return false;
    for (const c of f.children) if (c.type === 'INSTANCE' && ((await setOf(c)) || {}).name === 'Block/Header') return true;
    return false;
  }

  async function checkFrame(frame) {
    const names = [];
    placed = [];
    const blocks = pageBlocks(frame);
    for (const child of blocks) names.push(await checkBlock(frame, child, 0, null));
    if (names[0] !== 'Block/Header') add(frame, 'Page', 'The Header comes first.', blocks[0]);
    if (names[names.length - 1] !== 'Block/Footer') add(frame, 'Page', 'The Footer comes last.', blocks[blocks.length - 1]);
    const heroes = names.filter((n) => n === 'Block/Hero CTA').length;
    if (heroes !== 1) add(frame, 'Page', `A page has one Hero CTA; this one has ${heroes}.`);
    else if (names[1] !== 'Block/Hero CTA') add(frame, 'Page', 'The Hero CTA comes right after the Header.', blocks[1]);
    for (const limited of ['Block/Trio CTA', 'Block/Image with text']) {
      let run = 0;
      names.forEach((n, i) => { run = n === limited ? run + 1 : 0; if (run === 3) add(frame, 'Page', `More than two ${limited.replace('Block/', '')} blocks in a row.`, blocks[i]); });
    }
    // Image banners are taller on a page without a full-bleed hero (blocks.md → Banner, Page mode): every
    // hero is full-bleed but the mini image hero.
    const prop = propOf;
    const hero = blocks.find((c, i) => names[i] === 'Block/Hero CTA');
    const fullBleedHero = hero ? !/^Mini/.test(String(prop(hero, 'Design'))) : false;
    blocks.forEach((child, i) => {
      if (names[i] !== 'Block/Banner') return;
      const design = String(prop(child, 'Design'));
      const taller = prop(child, 'Page without a full-bleed hero');
      if (!/^Image/.test(design) || design === 'Image only' || taller === undefined) return;
      if (fullBleedHero && taller) add(frame, 'Banner', 'This page starts with a full-bleed hero, so its image banners are the shorter ones: switch off "Page without a full-bleed hero".', child);
      if (!fullBleedHero && !taller) add(frame, 'Banner', 'This page has a mini hero or none, so its image banners are taller: switch on "Page without a full-bleed hero".', child);
    });
    if (frame.layoutMode !== 'VERTICAL' || frame.itemSpacing !== 0) add(frame, 'Page', 'The page frame should be a vertical auto layout with no gap, so blocks stack as on the site.');
    const h1 = await checkContent(frame, placed, heroes === 1);
    const header = blocks.find((c, i) => names[i] === 'Block/Header');
    const unit = header ? header.findAllWithCriteria({ types: ['TEXT'] }).filter((t) => t.name === 'Unit' && shown(t, header)).map((t) => t.characters.trim()).join(' / ') : '';
    sites.push({ frame, unit, header, nav: header ? await navOf(header) : [], h1 });
    const build = [];
    for (const c of blocks) if (c.type === 'INSTANCE') build.push(await buildItem(c));
    return { blocks: names.length, build };
  }

  // Across the pages checked together (Phase 4): pages of one site, by the Header's unit name, have the
  // same navigation (a site has one main menu) and different H1s (page titles are unique: content.md →
  // Headings and page titles). A finding goes on the later page, naming the first.
  const sites = [];
  function acrossPages() {
    const seen = {};
    for (const p of sites) {
      if (!p.unit) continue;
      const first = seen[p.unit];
      if (!first) { seen[p.unit] = { page: p, titles: new Map(p.h1 ? [[p.h1.text.trim().toLowerCase(), p]] : []) }; continue; }
      const a = first.page.nav.map((n) => n.label).join(' | ');
      const b = p.nav.map((n) => n.label).join(' | ');
      if (a !== b) add(p.frame, 'Header', `The navigation differs from "${first.page.frame.name}", a page of the same site (${p.unit}): a site has one main menu. There: ${a || 'none'}. Here: ${b || 'none'}.`, p.header);
      if (p.h1) {
        const key = p.h1.text.trim().toLowerCase();
        const twin = first.titles.get(key);
        if (twin) add(p.frame, 'Page', `The same H1 as "${twin.frame.name}" ("${clip(p.h1.text)}"): each page of a site needs its own title. Check which one is right.`, p.h1.node, 'check', 'content');
        else first.titles.set(key, p);
      }
    }
  }

  // ---- Content: the words on the page (docs/content.md; figma.md → Page check plan, Phase 2) -----------
  // Read from the text already in the file: text layers, the text properties of buttons, links and
  // navigation items, and link addresses set on text. The Header and Footer carry the site's standard
  // navigation and footer, so only their navigation labels are checked.

  const styleNames = {};
  async function styleOf(t) {
    const id = t.textStyleId;
    if (typeof id !== 'string' || !id) return '';
    if (!(id in styleNames)) { const st = await figma.getStyleByIdAsync(id); styleNames[id] = st ? st.name : ''; }
    return styleNames[id];
  }
  const shown = (n, root) => { for (let p = n; p && p !== root; p = p.parent) if (p.visible === false) return false; return true; };
  const wordsOf = (s) => String(s).match(/[A-Za-z0-9][A-Za-z0-9’'&.-]*/g) || [];
  const clip = (s, n = 40) => { const t = String(s).replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1) + '…' : t; };
  const sentencesOf = (s) => String(s).replace(/([.!?])\s+(?=[A-Z0-9"“‘'(])/g, '$1\u0000').split('\u0000').map((x) => x.trim()).filter((x) => wordsOf(x).length);
  const SMALL = new Set('a an and as at but by for from in into nor of on or per the to vs via with'.split(' '));
  const isAcronym = (w) => /^[A-Z][A-Z0-9]+s?$/.test(w);
  // Title Case: every word after the first, other than short joining words and acronyms, starts with a capital.
  function titleCase(text) {
    const rest = wordsOf(text).slice(1).filter((w) => /^[A-Za-z]/.test(w) && !SMALL.has(w.toLowerCase()) && !isAcronym(w));
    return rest.length > 0 && rest.every((w) => /^[A-Z]/.test(w));
  }
  const placeholder = (s) => /\bstand-in\b|lorem ipsum/i.test(s);

  // Link and button text that doesn't say where it goes (content.md → Buttons and links).
  const VAGUE = new Set(['click here', 'click', 'here', 'learn more', 'read more', 'more', 'more info', 'more information', 'find out more', 'see more', 'details', 'link', 'this link', 'go']);
  const vague = (s) => VAGUE.has(String(s).toLowerCase().replace(/[^a-z ]/g, ' ').replace(/\s+/g, ' ').trim());
  const UNAPPROVED_FORM = /forms\.gle|docs\.google\.com\/forms|jotform\.|typeform\./i;
  const VERBS = new Set(('access apply ask attend begin book browse build buy call change chat check choose compare complete connect contact continue create discover donate download email enrol enter explore filter find follow get give go hear join learn listen log login make meet open order pay plan prepare print reach read register renew report request reserve reset return review save schedule search see select send share shop show sign start submit subscribe support take tell try update upload use view visit vote watch write').split(' '));

  // content.md → Grammar and style: [pattern, what to write instead]. Body text only.
  const STYLE = [
    [/\banalys(e|es|ed|ing)\b/i, 'analyze'], [/\bprogrammes?\b/i, 'program'], [/\be-mail\b/i, 'email'],
    [/\benroll(s|ment|ments)?\b/i, 'enrol, enrolment'], [/\badvisors?\b/i, 'adviser'], [/\barcheolog/i, 'archaeology'],
    [/\bcent(er|ered|ers)\b/i, 'centre'], [/\bcentred around\b/i, 'centred on'], [/\bon-line\b/i, 'online'],
    [/\bstart-ups?\b/i, 'startup'], [/\bfund[- ]rais/i, 'fundraising'], [/\btheaters?\b/i, 'theatre'],
    [/\d\s?%/, 'per cent (% only in headlines)'],
    [/\b\d{1,2}:00\s?(?:[ap]\.m\.|[ap]m\b)/i, '8 a.m., without ":00"'],
    [/\b\d{1,2}(:\d\d)?\s?([AaPp][Mm]|[AP]\.M\.)(?![A-Za-z])/, 'a.m. or p.m.'],
    [/\b(1[3-9]|2[0-3]):[0-5]\d\b/, 'the 12-hour clock (5:30 p.m.)'],
    [/\b(January|February|August|September|October|November|December) \d{1,2}\b/, 'Jan., Feb., Aug., Sept., Oct., Nov., Dec. before a date'],
    [/\b(Mar|Apr|Jun|Jul)\. ?\d/, 'March, April, June, July in full'], [/\bSep\. ?\d/, 'Sept.'],
  ];
  // content.md → Inclusive language. Check by hand: context decides.
  const INCLUSIVE = [
    [/\bpolicem[ae]n\b/i, 'police officer'], [/\bfirem[ae]n\b/i, 'firefighter'], [/\bmailm[ae]n\b/i, 'mail carrier'],
    [/\balderm[ae]n\b/i, 'councillor'], [/\bstewardess(es)?\b/i, 'flight attendant'],
    [/\bCanada[’']s Indigenous Peoples?\b/i, 'Indigenous Peoples in Canada'], [/\bnatives?\b/i, 'Indigenous, or the community’s own name'],
    [/\bsexual preference\b/i, 'sexual orientation'], [/\btransgendered\b/i, 'transgender'], [/\bhomosexuals?\b/i, 'gay, lesbian'],
    [/\bpioneer(s|ing|ed)?\b/i, 'a word without colonial overtones'], [/\bwalk(s|ed|ing)? the stage\b/i, 'cross the stage'], [/\bgung[- ]ho\b/i, 'enthusiastic'],
  ];
  const CLAIMS = /\b(proves?|proven|cures?|breakthroughs?|first[- ]ever|unprecedented|transformational|groundbreaking|ground-breaking|world-leading|game-changing|revolutionary)\b/i;
  const PERSONAL_EMAIL = /\b[a-z]+[._-][a-z]+@ucalgary\.ca\b/i;
  // Acronyms anyone reading knows, and degrees (content.md → Grammar and style).
  const KNOWN = new Set(('AI GPS NASA USA US UK OK FAQ FAQs PDF URL TV CEO ID GPA UCalgary CV PhD BA BSc BComm BEd BFA BKin BMus BN BSW MA MSc MBA MD MEd MEng MFA MN MSW JD LLM DVM EdD DBA DN DDes MArch MKin LLD SAIT CPR COVID STEM').split(' '));
  const NOT_BODY = /^(Heading\/|Button\/|Header\/|Footer\/|Label\/|Checklist\/Step number|Accordion\/Sub-section number|Events\/Date day)/;
  const CHROME = new Set(['Block/Header', 'Block/Footer']);

  // Grade level (Flesch–Kincaid) of a stretch of text.
  function syllables(word) {
    const w = word.toLowerCase().replace(/[^a-z]/g, '');
    if (!w) return 0;
    if (w.length <= 3) return 1;
    const groups = w.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '').replace(/^y/, '').match(/[aeiouy]{1,2}/g);
    return Math.max(1, groups ? groups.length : 1);
  }
  function grade(text) {
    const ws = wordsOf(text).filter((w) => /[A-Za-z]/.test(w));
    const ss = Math.max(1, sentencesOf(text).length);
    if (!ws.length) return 0;
    const syl = ws.reduce((n, w) => n + syllables(w), 0);
    return 0.39 * (ws.length / ss) + 11.8 * (syl / ws.length) - 15.59;
  }

  async function checkContent(frame, blocks, oneHero) {
    const C = (where, message, node, level) => add(frame, where, message, node, level, 'content');
    const headings = [];
    const prose = [];   // { text, node, label } body text, page order
    const actions = []; // { kind: 'button'|'link', text, url, node, label }

    for (const { node: block, name, label } of blocks) {
      const chrome = CHROME.has(name);
      const texts = block.findAllWithCriteria({ types: ['TEXT'] }).filter((t) => shown(t, block));
      const instances = [block].concat(block.findAllWithCriteria({ types: ['INSTANCE'] }).filter((i) => shown(i, block)));

      // Stand-in copy (must fix) and the library's sample text (check by hand), once per block.
      const stand = texts.filter((t) => placeholder(t.characters));
      if (stand.length) C(label, `${stand.length === 1 ? 'A text is' : stand.length + ' texts are'} still stand-in copy ("${clip(stand[0].characters)}"): write the page's own.`, stand[0], 'must');
      const samples = [];
      for (const inst of instances) {
        const set = await setOf(inst);
        if (!set) continue;
        const sname = set.name;
        const defs = set.componentPropertyDefinitions || {};
        for (const [key, prop] of Object.entries(inst.componentProperties || {})) {
          if (prop.type !== 'TEXT') continue;
          const text = String(prop.value);
          const field = bare(key).replace(/\s*\([^)]*\)\s*$/, '');
          if (!chrome && field !== 'Number' && defs[key] && defs[key].defaultValue === prop.value && !placeholder(text)) samples.push({ text, inst });
          if (sname === '_Button' && field === 'Label') actions.push({ kind: 'button', text, node: inst, label });
          else if ((sname === '_Link' && field === 'Label') || field === 'Link text') actions.push({ kind: 'link', text, node: inst, label });
          else if (/nav item$/.test(sname) && field === 'Label') {
            // content.md → Navigation labels: top level.
            const ws = wordsOf(text).filter((w) => w !== '&');
            const why = [];
            if (ws.length > 2) why.push('two words at most');
            if (/\band\b/i.test(text)) why.push('"&" for "and"');
            if (/\b(our|my|your)\b/i.test(text)) why.push('no "our", "my" or "your"');
            if (/\?|^(how|what|where|why|when|who|can)\b/i.test(text)) why.push('a noun, not a question');
            if (ws.slice(1).some((w) => /^[a-z]/.test(w) && !SMALL.has(w))) why.push('Title Case');
            if (why.length) C(label, `Navigation label "${clip(text)}": ${why.join('; ')}.`, inst, 'tip');
          } else if (/^_?Chip$/.test(sname) && field === 'Label') {
            // content.md → Navigation labels and tags.
            const why = [];
            if (text !== text.toLowerCase() && !wordsOf(text).every(isAcronym)) why.push('lowercase');
            if (wordsOf(text).length > 2) why.push('one or two words');
            if (wordsOf(text).some(isAcronym) && !wordsOf(text).every((w) => KNOWN.has(w))) why.push('the full term, not an acronym');
            if (why.length) C(label, `Tag "${clip(text)}": ${why.join('; ')}.`, inst, 'tip');
          }
        }
      }
      if (samples.length) C(label, `${samples.length === 1 ? 'A text is' : samples.length + ' texts are'} still the library's sample text ("${clip(samples[0].text)}"): replace ${samples.length === 1 ? 'it' : 'them'}, or keep ${samples.length === 1 ? 'it if it is' : 'them if they are'} this page's own.`, samples[0].inst, 'check');

      for (const t of texts) {
        const style = await styleOf(t);
        const h = /^Heading\/H(\d)/.exec(style);
        if (h && !chrome) headings.push({ level: Number(h[1]), text: t.characters, node: t, label });
        // Link addresses set on the text itself.
        if (typeof t.getStyledTextSegments === 'function') {
          for (const seg of t.getStyledTextSegments(['hyperlink'])) {
            if (seg.hyperlink && seg.hyperlink.type === 'URL') actions.push({ kind: 'link', text: seg.characters, url: seg.hyperlink.value, node: t, label });
          }
        }
        if (style === 'Header/Menu link') {
          const ws = wordsOf(t.characters).filter((w) => w !== '&');
          const why = [];
          if (ws.length > 4) why.push('two to four words');
          if (/\b(our|my|your)\b/i.test(t.characters)) why.push('no "our", "my" or "your"');
          if (why.length) C(label, `Navigation label "${clip(t.characters)}": ${why.join('; ')}.`, t, 'tip');
        }
        if (UNAPPROVED_FORM.test(t.characters)) C(label, `A link to a form tool the university doesn't approve ("${clip(t.characters)}"): use a Drupal webform, Qualtrics or SharePoint.`, t, 'must');
        if (!chrome && !h && !NOT_BODY.test(style) && !placeholder(t.characters) && t.characters.trim()) prose.push({ text: t.characters, node: t, label });
      }
    }

    // Headings: one H1 (the hero's), no skipped level, sentence case, no closing period or "!".
    // The styles say how big a heading is, not its level in the page's code, so a skip is checked by hand.
    const h1 = headings.filter((x) => x.level === 1);
    const title = h1.length === 1 ? h1[0] : null;
    if (oneHero && h1.length !== 1) C('Page', `A page has one H1 (the Hero CTA's title); this one has ${h1.length}.`, h1[1] ? h1[1].node : null, 'must');
    let previous = 0;
    for (const x of headings) {
      if (previous && x.level > previous + 1) C(x.label, `"${clip(x.text)}" is an H${x.level} after an H${previous}: check that no heading level is skipped in the page's code.`, x.node, 'check');
      previous = x.level;
      const why = [];
      if (/[.!]\s*$/.test(x.text) && !/\.\.\.\s*$|…\s*$/.test(x.text)) why.push('no closing period or "!"');
      if (titleCase(x.text)) why.push('sentence case, unless these are proper names');
      if (why.length) C(x.label, `Heading "${clip(x.text)}": ${why.join('; ')}.`, x.node, 'tip');
    }

    // Buttons and links.
    const byText = {};
    for (const a of actions) {
      const text = String(a.text).trim();
      if (vague(text)) { C(a.label, `${a.kind === 'button' ? 'Button' : 'Link'} text "${clip(text)}" doesn't say where it goes: name the destination or action ("Read the program requirements").`, a.node, 'must'); continue; }
      if (a.url && UNAPPROVED_FORM.test(a.url)) C(a.label, `"${clip(text)}" links to a form tool the university doesn't approve: use a Drupal webform, Qualtrics or SharePoint.`, a.node, 'must');
      const why = [];
      if (a.kind === 'button') {
        const ws = wordsOf(text);
        if (ws.length > 4) why.push('2–4 words');
        if (/[A-Z]{2}/.test(text) && text === text.toUpperCase() && (ws.length > 1 || text.length > 5)) why.push('sentence case, not all caps');
        if (ws.length && !VERBS.has(ws[0].toLowerCase())) why.push('start with a verb');
      } else {
        if (/^(https?:\/\/|www\.)|\.(ca|com|org|net)\/\S/i.test(text)) why.push('descriptive words, not the address');
        if (a.url) {
          const file = /\.(pdf|docx?|xlsx?|pptx?)(\?|#|$)/i.exec(a.url);
          if (file && !new RegExp('\\(' + file[1].slice(0, 3), 'i').test(text)) why.push(`say it's a file: "(${file[1].toUpperCase().replace(/X$/, '')})"`);
          const host = (/^[a-z]+:\/\/([^/?#]+)/i.exec(a.url) || [])[1];
          if (host && !/(^|\.)ucalgary\.ca$/i.test(host) && !/\([a-z0-9.-]+\.[a-z]{2,}\)/i.test(text)) why.push(`name the outside site: "(${host.replace(/^www\./, '')})"`);
          const key = text.toLowerCase();
          if (byText[key] && byText[key].url !== a.url) why.push('the same text as a link to somewhere else');
          byText[key] = byText[key] || a;
        }
      }
      if (why.length) C(a.label, `${a.kind === 'button' ? 'Button' : 'Link'} "${clip(text)}": ${why.join('; ')}.`, a.node, 'tip');
    }

    // Body text: style and word list, inclusive language, research claims, personal email addresses,
    // paragraphs and sentences, centred text, line length.
    // Per block: its text for the reading level, its style points and its widest lines, each reported once.
    const blockText = {};
    for (const p of prose) {
      const text = p.text;
      const b = blockText[p.label] = blockText[p.label] || { text: '', node: p.node, style: new Map(), wide: null };
      b.text += ' ' + text + (/[.!?]\s*$/.test(text) ? '' : '.');
      for (const [re, fix] of STYLE) { const m = re.exec(text); if (m && !b.style.has(fix)) b.style.set(fix, { found: m[0], node: p.node }); }
      const inclusive = INCLUSIVE.filter(([re]) => re.test(text)).map(([re, fix]) => `"${re.exec(text)[0]}" (${fix})`);
      if (inclusive.length) C(p.label, `Inclusive language: ${inclusive.join('; ')}. Check the context.`, p.node, 'check');
      const claim = CLAIMS.exec(text);
      if (claim) C(p.label, `"${claim[0]}": a claim to verify. Prefer "found", "suggests" or "indicates" unless it can be shown.`, p.node, 'check');
      const email = PERSONAL_EMAIL.exec(text);
      if (email) C(p.label, `A personal email address (${email[0]}): it needs the person's consent; a generic address or a webform is preferred.`, p.node, 'check');
      const why = [];
      if (text.split(/\n+/).some((para) => sentencesOf(para).length > 4)) why.push('a paragraph of more than 4 sentences');
      const long = sentencesOf(text).find((x) => wordsOf(x).length > 25);
      if (long) why.push(`a sentence of ${wordsOf(long).length} words ("${clip(long, 30)}")`);
      const size = typeof p.node.fontSize === 'number' ? p.node.fontSize : 0;
      const perLine = size ? p.node.width / (size * 0.5) : 0;
      if (perLine && p.node.textAlignHorizontal === 'CENTER' && text.length > 2 * perLine) why.push('centred text longer than two lines: left-align it');
      if (perLine > 90 && text.length > 90 && (!b.wide || perLine > b.wide.perLine)) b.wide = { perLine, node: p.node };
      if (why.length) C(p.label, `Plain language: ${why.join('; ')}.`, p.node, 'tip');
    }
    for (const [label, b] of Object.entries(blockText)) {
      if (b.style.size) {
        const list = [...b.style].map(([fix, x]) => `"${x.found}" → ${fix}`);
        C(label, `Style: ${list.join('; ')}${/[.)"]$/.test(list[list.length - 1]) ? '' : '.'}`, [...b.style.values()][0].node, 'tip');
      }
      if (b.wide) C(label, `Plain language: lines of about ${Math.round(b.wide.perLine)} characters: 45–90 read best.`, b.wide.node, 'tip');
      const g = grade(b.text);
      if (wordsOf(b.text).length >= 40 && Math.round(g) > 9) C(label, `Reading level about grade ${Math.round(g)}: aim for grade 8–9. Shorter sentences and everyday words bring it down.`, b.node, 'tip');
    }

    // Acronyms: spelled out where first used, as "Full Name (ACR)". Headings count; all-caps text doesn't.
    const seen = new Set();
    const ordered = headings.map((x) => ({ text: x.text, node: x.node, label: x.label })).concat(prose);
    for (const p of ordered) {
      if (p.text === p.text.toUpperCase()) continue;
      const re = /\b[A-Z][A-Z0-9]{2,5}s?\b/g; // three letters or more: two are often initials
      let m;
      while ((m = re.exec(p.text))) {
        const acr = m[0].replace(/s$/, '');
        if (seen.has(acr) || KNOWN.has(acr) || KNOWN.has(m[0])) continue;
        seen.add(acr);
        const introduced = p.text[m.index - 1] === '(' && p.text[m.index + m[0].length] === ')';
        if (!introduced) C(p.label, `"${acr}" isn't spelled out where it is first used: write the full name, then "(${acr})".`, p.node, 'tip');
      }
    }
    return title;
  }

  let frames = [];
  if (FRAME_ID) {
    for (const id of [].concat(FRAME_ID)) { const f = await figma.getNodeByIdAsync(id); if (f) frames.push(f); }
  } else {
    const page = PAGE_ID ? await figma.getNodeByIdAsync(PAGE_ID) : figma.currentPage;
    await figma.setCurrentPageAsync(page);
    for (const f of page.children) if (await isPage(f)) frames.push(f);
  }
  const checked = [];
  for (const f of frames) { const r = await checkFrame(f); checked.push({ page: f.name, id: f.id, blocks: r.blocks, build: r.build }); }
  acrossPages();
  // Must fix first, then check by hand, then tips; the order the check found them within each level.
  issues.sort((a, b) => LEVELS.indexOf(a.level) - LEVELS.indexOf(b.level));
  const counts = Object.fromEntries(LEVELS.map((l) => [l, issues.filter((i) => i.level === l).length]));
  const summary = [counts.must && `${counts.must} must fix`, counts.check && `${counts.check} to check by hand`, counts.tip && `${counts.tip} tip(s)`].filter(Boolean).join(', ');
  return { rules: RULES, checked, issues, counts, result: issues.length ? summary : 'Nothing to fix' };
}

// The Page check's report and build list as text, for Copy report and Export (figma.md → Page check plan,
// Phase 5 and 6). Plain functions of the check's result: no Figma API here, so the tests run them as they
// are. scripts/build-figma-plugin.mjs puts this file between the check and src/main.js.

// What the check can't see: a person checks these (content.md → In the Page check). The tests fail when
// this list and content.md's differ.
const CANT_CHECK = [
  'alt text',
  'contrast on photos',
  'AI-generated images',
  'copyright',
  'linked documents',
  'keyboard order',
  'working links',
  'page titles and URLs',
  'captions and transcripts',
  'page planning and review',
];

const LEVEL_NAMES = { must: 'Must fix', check: 'Check by hand', tip: 'Tip' };
const SECTION_NAMES = { structure: 'Structure', content: 'Content' };

// A tip's key, to hide it on this computer: the page frame, where and what. A tip whose text changes
// (its page changed) comes back.
function tipKey(issue) {
  return issue.frame + '|' + issue.where + '|' + issue.message;
}

// "2 must fix · 1 to check by hand · 3 tips", leaving out a level with none.
function tally(issues) {
  const n = (level) => issues.filter((i) => i.level === level).length;
  const parts = [];
  if (n('must')) parts.push(n('must') + ' must fix');
  if (n('check')) parts.push(n('check') + ' to check by hand');
  if (n('tip')) parts.push(n('tip') + (n('tip') === 1 ? ' tip' : ' tips'));
  return parts.join(' · ');
}

// One line of Markdown: no line breaks, and the characters that would start a list or heading escaped.
const md = (s) => String(s).replace(/\s+/g, ' ').replace(/([\\`*_[\]<>|])/g, '\\$1').trim();

// The report, in Markdown: the result, each page's findings by section and level (hidden tips counted,
// not listed), and what the check can't see. meta: { file, page, when (a Date), selection }.
function reportMarkdown(result, meta) {
  const shown = result.issues.filter((i) => !i.hidden);
  const hidden = result.issues.length - shown.length;
  const out = [];
  out.push('# Page check: ' + md(meta.page));
  out.push('');
  out.push('File: ' + md(meta.file) + ' · ' + (meta.selection ? 'Selected pages' : 'Every page on this Figma page') + ' · Checked ' + stamp(meta.when) + ' · Rules version ' + result.rules.version + ' (' + result.rules.date + ')');
  out.push('');
  const must = shown.filter((i) => i.level === 'must').length;
  out.push('**' + (must ? must + (must === 1 ? ' thing to fix' : ' things to fix') : shown.length ? 'Nothing must be fixed' : 'Nothing to fix') + '**' + (shown.length ? ': ' + tally(shown) : '') + (hidden ? ' (' + hidden + (hidden === 1 ? ' tip' : ' tips') + ' hidden)' : ''));
  for (const frame of result.checked) {
    const mine = shown.filter((i) => i.frame === frame.id);
    const hiddenHere = result.issues.filter((i) => i.frame === frame.id && i.hidden).length;
    out.push('');
    out.push('## ' + md(frame.page));
    out.push('');
    out.push(frame.blocks + ' items · ' + (mine.length ? tally(mine) : 'nothing to fix') + (hiddenHere ? ' · ' + hiddenHere + (hiddenHere === 1 ? ' tip' : ' tips') + ' hidden on this computer' : ''));
    for (const section of Object.keys(SECTION_NAMES)) {
      const found = mine.filter((i) => i.section === section);
      if (!found.length) continue;
      out.push('');
      out.push('### ' + SECTION_NAMES[section]);
      out.push('');
      for (const level of Object.keys(LEVEL_NAMES)) {
        for (const i of found.filter((x) => x.level === level)) out.push('- **' + LEVEL_NAMES[level] + '** · ' + md(i.where) + ': ' + md(i.message));
      }
    }
  }
  out.push('');
  out.push("## What the check can't see");
  out.push('');
  out.push('Check these by hand before the page is published (content.md → In the Page check):');
  out.push('');
  for (const item of CANT_CHECK) out.push('- [ ] ' + item.charAt(0).toUpperCase() + item.slice(1));
  return out.join('\n') + '\n';
}

// The results as JSON: the same as the report, with every finding (hidden tips marked) and each page's
// build list.
function reportJson(result, meta) {
  return JSON.stringify({
    file: meta.file,
    page: meta.page,
    selection: !!meta.selection,
    checked: stamp(meta.when),
    rules: result.rules,
    result: result.result,
    counts: result.counts,
    pages: result.checked.map((f) => ({ page: f.page, id: f.id, items: f.blocks, build: f.build })),
    findings: result.issues.map((i) => ({ page: i.page, frame: i.frame, level: i.level, section: i.section, where: i.where, message: i.message, layer: i.id, hidden: !!i.hidden })),
    notChecked: CANT_CHECK,
  }, null, 2) + '\n';
}

// The build list, in Markdown (Phase 6): each page's blocks in order, as they are built in Drupal's
// Layout Builder, with their designs, switches, item counts and text.
function buildListMarkdown(result, meta) {
  const out = ['# Build list: ' + md(meta.page), '', 'File: ' + md(meta.file) + ' · ' + stamp(meta.when) + ' · from the Page check, rules version ' + result.rules.version, ''];
  out.push('Build each page top to bottom. Check the page first: a block with a must fix is not ready to build.');
  for (const frame of result.checked) {
    out.push('');
    out.push('## ' + md(frame.page));
    out.push('');
    (frame.build || []).forEach((item, n) => buildLines(item, (n + 1) + '. ', '   ', out));
  }
  return out.join('\n') + '\n';
}

function buildLines(item, first, indent, out) {
  const props = Object.entries(item.properties || {}).map(([k, v]) => k + ': ' + (v === true ? 'on' : v === false ? 'off' : v));
  out.push(first + '**' + md(item.block) + '**' + (props.length ? ' · ' + md(props.join(' · ')) : ''));
  if (item.navigation) out.push(indent + '- Navigation: ' + md(item.navigation.join(' | ') || 'none'));
  for (const l of item.lists || []) out.push(indent + '- ' + md(l.list) + ': ' + l.items);
  for (const t of item.text || []) out.push(indent + '- ' + md(t.layer) + ': “' + md(t.text) + '”');
  for (const r of item.regions || []) {
    out.push(indent + '- ' + md(r.region) + (r.blocks.length ? '' : ': empty'));
    r.blocks.forEach((b) => buildLines(b, indent + '  - ', indent + '    ', out));
  }
}

// 2026-11-09 14:05, in the computer's own time.
function stamp(when) {
  const d = when instanceof Date ? when : new Date(when);
  const p = (n) => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
}

// The plugin around the page check: runs it on the page that is open (or on the page frames that are
// selected), shows what it found in a panel, and selects a finding's layer when it is clicked.
// runCheck() is scripts/figma-check-page.js and the report functions are src/report.js, both put in front
// of this file by scripts/build-figma-plugin.mjs.
// It changes nothing in the file. What it keeps (hidden tips, whether to check again on a change) is kept
// on this computer (figma.clientStorage), never in the file.
figma.showUI(__html__, { width: 400, height: 600, themeColors: true });

// Hidden tips are kept per file: a tip's key holds layer ids, which mean something only in their file.
const fileName = figma.fileKey || figma.root.name;
const HIDDEN = 'hidden-tips:' + fileName;
const AUTO = 'check-on-change';
let last = null;      // the last result, with what it was run on
let hidden = [];      // keys of hidden tips (tipKey in report.js)
let auto = false;     // check again when the page changes
let running = false;
let timer = null;

const store = {
  get: async (key, fallback) => { try { const v = await figma.clientStorage.getAsync(key); return v === undefined ? fallback : v; } catch (e) { return fallback; } },
  set: async (key, value) => { try { await figma.clientStorage.setAsync(key, value); } catch (e) { /* the panel still works */ } },
};

// The result with each tip's hidden mark, and the report, results and build list as text.
function send() {
  if (!last) return;
  const issues = last.result.issues.map((i) => Object.assign({}, i, { key: tipKey(i), hidden: i.level === 'tip' && hidden.includes(tipKey(i)) }));
  const result = Object.assign({}, last.result, { issues: issues });
  const meta = { file: figma.root.name, page: last.page, when: last.when, selection: last.selection };
  figma.ui.postMessage({
    type: 'result', page: last.page, selection: last.selection, rules: result.rules, auto: auto,
    checked: result.checked.map((c) => ({ page: c.page, id: c.id, blocks: c.blocks })), issues: issues,
    report: reportMarkdown(result, meta), json: reportJson(result, meta), build: buildListMarkdown(result, meta),
  });
}

async function run() {
  if (running) return;
  running = true;
  figma.ui.postMessage({ type: 'busy' });
  try {
    const picked = figma.currentPage.selection.filter(function (n) {
      return (n.type === 'FRAME' || n.type === 'INSTANCE') && n.parent && n.parent.type === 'PAGE' && Math.abs(n.width - 1440) <= 1;
    });
    // The selected page frames in one run, so the checks across pages see them together.
    const result = await runCheck(null, picked.length ? picked.map((n) => n.id) : null);
    last = { result: result, page: figma.currentPage.name, selection: picked.length > 0, when: new Date() };
    send();
  } catch (error) {
    figma.ui.postMessage({ type: 'error', message: String(error && error.message ? error.message : error) });
  }
  running = false;
}

// Check again a moment after the page stops changing, when the designer has asked for it.
function changed() {
  if (!auto) return;
  if (timer) clearTimeout(timer);
  timer = setTimeout(function () { timer = null; run(); }, 1500);
}
let watched = null;
function watch() {
  if (watched) { try { watched.off('nodechange', changed); } catch (e) { /* page gone */ } }
  watched = figma.currentPage;
  watched.on('nodechange', changed);
}
figma.on('currentpagechange', function () { watch(); if (auto) run(); });

figma.ui.onmessage = async function (message) {
  if (message.type === 'run') await run();
  if (message.type === 'show') {
    const node = await figma.getNodeByIdAsync(message.id);
    if (!node) { figma.notify('That layer is no longer on the page: check again.'); return; }
    try {
      figma.currentPage.selection = [node];
      figma.viewport.scrollAndZoomIntoView([node]);
    } catch (error) {
      figma.notify('Could not select that layer.');
    }
  }
  if (message.type === 'hide' && !hidden.includes(message.key)) {
    hidden = hidden.concat([message.key]).slice(-500);
    await store.set(HIDDEN, hidden);
    send();
  }
  if (message.type === 'unhide') {
    hidden = [];
    await store.set(HIDDEN, hidden);
    send();
  }
  if (message.type === 'auto') {
    auto = !!message.on;
    await store.set(AUTO, auto);
  }
  if (message.type === 'copied') figma.notify('Report copied.');
  if (message.type === 'saved') figma.notify('Saved ' + message.name + '.');
};

(async function start() {
  hidden = await store.get(HIDDEN, []);
  auto = await store.get(AUTO, false);
  watch();
  await run();
})();
